<?php

namespace App\Http\Controllers;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\Client;
use App\Models\Dispatcher;
use App\Models\Finance;
use App\Models\Monitor;
use App\Models\Driver;
use App\Models\User;
use App\Models\Location;
use App\Models\AssignOrders;
use App\Models\Districts;
use App\Models\DistrictsPrices;
use App\Models\Order;
use App\Models\Notifications;

class ClientController extends Controller
{
    public function Order(Request $request){
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin' || Auth::user()->type == 'client') {
            $locations = Location::all();
            $user = User::with('client')->where('id', Auth::user()->id)->first();
            return view('client.Order',compact(['locations', 'user']));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }

    public function submitOrdes(Request $request){
        $Order = new Order();
        $client = Client::with('user')->where('user_id', Auth::user()->id)->first();
        $Order->status           =  'Pending';
        $Order->client_id        =  $client->id;
        $Order->SenderNumber     =  $client->user->phone;
        $Order->SenderName       =  $client->user->name;
        $Order->RecipientNumber  =  $request->Recipientnumber;
        $Order->RecipientName    =  $request->Recipientname;
        $Order->city             =  $request->city;
        $Order->districts        =  $request->district;
        $Order->locations        =  $request->location;
        $Order->RecipientAddress =  $request->Recipientaddress;
        $Order->itemPrice        =  $request->itemprice;
        $Order->deliveryPrice    =  $request->deliveryprice;
        $Order->totalPrice       =  $request->totalprice;
        $Order->lat              =  0.000000;
        $Order->lon              =  0.000000;
        $Order->notes            =  $request->notes;
        $Order->barcode          =  rand(1000, 9999);
        $Order->save();
        
        $dispatchers = Dispatcher::with('user')->get();
        foreach($dispatchers as $dispatcher) {
            if (isset($dispatcher->user)) {
                $message = 'There is a new order !'; 
                $title = 'Hello '.$dispatcher->user->name;
                $player_id = $dispatcher->user->player_id;
                if (isset($dispatcher->user->player_id) && $player_id != '') {
                    app('App\Http\Controllers\NotificationController')->sendNtoification($player_id, $message, $title);
                }
            }
        }
        
        $notifications = new Notifications();
        $notifications->order_id = $Order->id;
        $notifications->message = " New Order need to Assign !.";
        $notifications->is_seen = 0;
		$notifications->save();
        return redirect()->back()->with('success', 'تم ارسال طلبك بنجاح ');
    }

    public function viewOrder(Request $request)
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin' || Auth::user()->type == 'client') {
            $client = Client::with('user')->where('user_id', auth()->id())->first();
            $Order = Order::where('client_id',$client->id)->get();
            $Orderpinnding = Order::where('client_id',$client->id)->where('status','Pending')->get();
            $Orderdelivered = Order::where('client_id',$client->id)->where('status','delivered')->get();
            $Ordercancelled = Order::where('client_id',$client->id)->where('status','!=','Pending')->where('status','!=','delivered')->where('status','!=','Out For Delivery')->get();
            return view('client.viewOrder',compact('Order','Orderpinnding','Orderdelivered','Ordercancelled'));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }

    public function getDeliveryPrice(Request $request)
    {
        $location = Location::where('city', $request->city)->first();

        if (is_null($location)) {
            $delivery_price = Client::where('user_id', Auth::user()->id)->select('other as delivery_price')->first();
        } else {
            $delivery_price = Client::where('user_id', Auth::user()->id)->select($location->Region . ' as delivery_price')->first();
        }
        return $delivery_price;
    }

    public function editOrder(Request $request)
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin' || Auth::user()->type == 'client') {
            $locations = Location::all();
            $user = User::with('client')->where('id', Auth::user()->id)->first();
            $order = Order::find($request->id);
            return view('client.editOrder',compact(['locations', 'user', 'order']));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }
    
    public function Viewclient(Request $request)
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin' || Auth::user()->type == 'client'|| Auth::user()->type == 'monitor'|| Auth::user()->type == 'dispatcher'|| Auth::user()->type == 'finance') {
            $user = User::with('client')->where('id', $request->id)->first();
            $Order = Order::where('client_id',$user->client->id)->with('assigned_order')->get();
            $itemPrice = Order::where('client_id',$user->client->id)->where('status','Delivered')->pluck('itemPrice')->sum();
            $deliveryPrice = Order::where('client_id',$user->client->id)->where('status','Delivered')->pluck('deliveryPrice')->sum();
            $totalPrice = Order::where('client_id',$user->client->id)->where('status','Delivered')->pluck('totalPrice')->sum();
            $count = Order::where('client_id',$user->client->id)->where('status','Delivered')->count();
            $districtsPrices = DistrictsPrices::where('user_id',$user->id)->with('Districts')->get();
            $OrderDelivered = Order::where('client_id',$user->client->id)->where('status','Delivered')->with('assigned_order')->get();
            return view('client.Viewclient',compact('OrderDelivered','user','Order','itemPrice','deliveryPrice','totalPrice','count','districtsPrices'));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }

    public function updateOrder(Request $request)
    {
            $Order = Order::find($request->id);            
            $client = Client::with('user')->where('user_id', Auth::user()->id)->first();
            $Order->status           =  $request->status;
            $Order->RecipientNumber  =  $request->Recipientnumber;
            $Order->RecipientName    =  $request->Recipientname;
            $Order->city             =  $request->city;
            $Order->RecipientAddress =  $request->Recipientaddress;
            $Order->itemPrice        =  $request->itemprice;
            $Order->deliveryPrice    =  $request->deliveryprice;
            $Order->totalPrice       =  $request->totalprice;
            $Order->lon              =  $request->lon;
            $Order->lat              =  $request->lat;
            $Order->notes            =  $request->notes;
            $Order->save();
            return redirect()->back()->with('success', 'تم نعديل الطلب بنجاح ');
    }
}
