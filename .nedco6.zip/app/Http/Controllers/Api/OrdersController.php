<?php

namespace App\Http\Controllers\Api;

use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use App\Models\Admin;
use App\Models\User;
use App\Models\Client;
use App\Models\Dispatcher;
use App\Models\Finance;
use App\Models\Monitor;
use App\Models\Driver;
use App\Models\Location;
use App\Models\Order;
use App\Models\AssignOrders;
use App\Models\FinancialAccounts;
use App\Models\DistrictsPrices;
use App\Models\City;
use App\Models\Notifications;
use Reflector;

class OrdersController extends Controller
{
    public function addOrder(Request $request)
    {

        $rules = [
            'deliveryprice' => 'required',
        ];

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            $response = ['status' => 400, 'message' => "Sorry We Don't Deliver to your area", 'success' => false];
            return response()->json($response, 200);
        }

        try {
            $city = City::find($request->city);
            $Order = new Order();
            $client = Client::with('user')->where('user_id', auth()->id())->first();
            $Order->status           =  'Pending';
            $Order->client_id        =  $client->id;
            $Order->SenderNumber     =  $request->SenderNumber;
            $Order->SenderName       =  $request->SenderName;
            $Order->RecipientNumber  =  $request->Recipientnumber;
            $Order->RecipientName    =  $request->Recipientname;
            $Order->city             =  $city->name;
            $Order->locations        =  $request->location;
            $Order->districts        =  $request->district;
            $Order->RecipientAddress =  $request->Recipientaddress;
            $Order->itemPrice        =  $request->itemprice;
            $Order->deliveryPrice    =  $request->deliveryprice;
            $Order->totalPrice       =  $request->totalprice;
            $Order->notes            =  $request->notes;
            $request->lat == '' ? $Order->lat = 0.000000 : $Order->lat = $request->lat;
            $request->lon == '' ? $Order->lon = 0.000000 : $Order->lon = $request->lon;
            $Order->barcode          =  rand(1000, 9999);
            $Order->save();
            
            $AssignOrders = AssignOrders::firstOrNew(array('order_id' => $request->order_id));
            $AssignOrders->Order_id      = $Order->id;
            $AssignOrders->delivery_date = date("Y-m-d", strtotime("+1 day"));
            $AssignOrders->save();

            $dispatchers = Dispatcher::with('user')->get();
            foreach($dispatchers as $dispatcher) {
                if (isset($dispatcher->user)) {
                    $message = 'There is a new order !'; 
                    $title = 'Hello '.$dispatcher->user->name;
                    $player_id = $dispatcher->user->player_id;
                    if (isset($dispatcher->user->player_id) && $player_id != '') {
                        app('App\Http\Controllers\NotificationController')->sendNtoification($player_id, $message, $title);
                    }
                }
            }
            
            $response = [
                'status' => 200,
                'message' => 'Order Added Seccussfully',
                'order' => $Order
            ];

            return response()->json($response, 200);
        } catch (\Exception $e) {

            if ($request->SenderNumber == '') {
                $response = ['status' => 400,'message' => "Sender Number Is Required"];
            } else if ($request->SenderName == '') {
                $response = ['status' => 400,'message' => "Sender Name Is Required"];
            } else if ($request->Recipientnumber == '') {
                $response = ['status' => 400,'message' => "Recipient Number Is Required"];
            } else if ($request->Recipientname == '') {
                $response = ['status' => 400,'message' => "Recipient Name Is Required"];
            } else if ($request->location == '') {
                $response = ['status' => 400,'message' => "Location Is Required"];
            } else if ($request->district == '') {
                $response = ['status' => 400,'message' => "District Is Required"];
            } else if ($request->city == '') {
                $response = ['status' => 400,'message' => "city Is Required"];
            } else {
                $response = ['status' => 400,'message' => $e->getMessage()];
            }

            return response()->json($response, 200);
        }
    }

    public function assignOrder(Request $request)
    {
        $AssignOrders = AssignOrders::firstOrNew(array('order_id' => $request->order_id));
        $AssignOrders->Driver_id     = $request->driver_id;
        $AssignOrders->Order_id      = $request->order_id;
        $AssignOrders->delivery_date = $request->delivery_date;
        $AssignOrders->save();

        $order  = Order::where('id', $request->order_id)->first();
        $client = Client::where('id', $order->client_id)->with('user')->first();
        $driver = Driver::with('user')->where('id',$request->driver_id)->first();

        $user = User::find($driver->user_id);
        $message = 'You Have a new order to deliver'; 
        $title = 'Hey '.$user->name;
        $player_id = $user->player_id;
        if (isset($user->player_id) && $player_id != '') {
            app('App\Http\Controllers\NotificationController')->sendNtoification($player_id, $message, $title);
        }
        
        $message = "The Order Number #".$request->order_id." Will Be Deliverd at ".$request->get('delivery_date').".";
        $title = 'Hey '.$client->user->name;
        $player_id = $client->user->player_id;
        if (isset($user->player_id) && $player_id != '') {
            app('App\Http\Controllers\NotificationController')->sendNtoification($player_id, $message, $title);
        }

        $response = [
            'status' => 200,
            'success' => true,      
            'message' => 'Success',
        ];

        return response()->json($response, 200);
    }


    public function changeOrderStatus(Request $request)
    {
        $order = Order::find($request->id);
        $order->status = $request->status;
        $order->payment_status = $request->payment_status;
        $order->save();

        $assigndOrder = AssignOrders::where('Order_id', $request->id)->first();
        $client = Client::where('id', $order->client_id)->with('user')->first();
        $driver = Driver::where('id', $assigndOrder->Driver_id)->with('user')->first();
        $districtsPrices = DistrictsPrices::where('user_id', $driver->user_id)->where('district_id', $order->districts)->first();

        if (isset($client->user->player_id)) {
            if ($request->status == 'Cancelled') {
                $message = 'Your Order Has been Cancelled'; 
                $title = 'Hello '.$client->user->name;
                app('App\Http\Controllers\NotificationController')->sendNtoification($client->user->player_id, $message, $title);
            } else if ($request->status == 'Out Of Reach') {
                $message = 'The recipient of the order number #'.$request->id.' is out of reach'; 
                $title = 'Hello '.$client->user->name;
                app('App\Http\Controllers\NotificationController')->sendNtoification($client->user->player_id, $message, $title);
            } else if ($request->status == 'Out For Delivery') {
                $message = 'Your Order Number #'.$request->id." Is on the way"; 
                $title = 'Hello '.$client->user->name;
                app('App\Http\Controllers\NotificationController')->sendNtoification($client->user->player_id, $message, $title);
            }
        }

        switch ($request->payment_status) {
            case 'Paid Full Amount':
                $financialClient = new FinancialAccounts();
                $financialClient->user_id = $client->user_id;
                if ($request->status == 'Delivered') {
                    $financialClient->price = $order->itemPrice;
                } else {
                    $financialClient->price = 0;
                }
                $financialClient->save();

                $financialDriver = new FinancialAccounts();
                $financialDriver->user_id = $driver->user_id;
                $financialDriver->price = $districtsPrices->price;
                $financialDriver->save();
                
                $notificationsDriver = new Notifications();
                $notificationsDriver->user_id = $client->user_id;
                $notificationsDriver->order_id = $request->id;
                if ($request->status == 'Cancelled') {
                    $notificationsDriver->message = "Your Order has been Cancelled";
                } else {
                    $notificationsDriver->message = "Your Order has been Arrived ,And Has Paid Full Amount.";
                }
                $notificationsDriver->is_seen = 0;
        		$notificationsDriver->save();
        		
                break;
            case 'Paid Only Delivery Costs':
                $financialClient = new FinancialAccounts();
                $financialClient->user_id = $client->user_id;
                $financialClient->price = 0;
                $financialClient->save();

                $financialDriver = new FinancialAccounts();
                $financialDriver->user_id = $driver->user_id;
                $financialDriver->price = $districtsPrices->price;
                $financialDriver->save();

                $notificationsDriver = new Notifications();
                $notificationsDriver->user_id = $client->user_id;
                $notificationsDriver->order_id = $request->id;
                if ($request->status == 'Cancelled') {
                    $notificationsDriver->message = "Your Order has been Cancelled";
                } else {
                    $notificationsDriver->message = "Your Order has been Arrived ,And Paid Only Delivery Costs.";
                }
                $notificationsDriver->is_seen = 0;
        		$notificationsDriver->save();
        		
                break;
            case 'Nothing Was Paid':
                $financialClient = new FinancialAccounts();
                $financialClient->user_id = $client->user_id;
                $financialClient->price = '-'.$order->deliveryPrice;
                $financialClient->save();
    
                $financialDriver = new FinancialAccounts();
                $financialDriver->user_id = $driver->user_id;
                $financialDriver->price = $districtsPrices->price;
                $financialDriver->save();
                
                $notificationsDriver = new Notifications();
                $notificationsDriver->user_id = $client->user_id;
                $notificationsDriver->order_id = $request->id;
                if ($request->status == 'Cancelled') {
                    $notificationsDriver->message = "Your Order has been Cancelled";
                } else {
                    $notificationsDriver->message = "Your Order has been Arrived ,And Nothing Was Paid.";
                }
                $notificationsDriver->is_seen = 0;
        		$notificationsDriver->save();
                break;
            default:
                # code...
                break;
        }

        $response = [
            'status' => 200,
            'message' => 'Order Status Changed Successfully ',
        ];

        return response()->json($response, 200);
    }

    public function getSingleOrder(Request $request)
    {
        $order = Order::with('assigned_order')->where('id', $request->order_id)->first();

        if (isset($order->assigned_order->Driver_id)){
            $driver = Driver::with('user')->where('id', $order->assigned_order->Driver_id)->first();
            $assigned_order = true;
        } else {
            $driver = null;
            $assigned_order = false;
        }

        $response = [
            'status'  => 200,
            'message' => 'Success',
            'order'   => $order,
            'driver'  => $driver,
            'assigned_order' => $assigned_order
        ];

        return response()->json($response, 200);        
    }
    
    public function getSingleOrderByBarcod(Request $request)
    {
        $order = Order::with('assigned_order')->where('barcode', $request->barcode)->first();

        if (isset($order->assigned_order)){
            $driver = Driver::with('user')->where('id', $order->assigned_order->Driver_id)->first();
        } else {
            $driver = null;
        }

        $response = [
            'status'  => 200,
            'message' => 'Success',
            'order'   => $order,
            'driver'  => $driver
        ];

        return response()->json($response, 200);        
    }
}
