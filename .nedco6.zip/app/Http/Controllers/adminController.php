<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\Admin;
use App\Models\User;
use App\Models\Client;
use App\Models\Dispatcher;
use App\Models\Finance;
use App\Models\Monitor;
use App\Models\Driver;
use App\Models\Pickedup;
use App\Models\Location;
use App\Models\Order;
use App\Models\City;
use App\Models\Districts;
use App\Models\DistrictsPrices;
use App\Models\AssignOrders;
use App\Models\Notifications;
use Illuminate\Support\Facades\Validator;
use DB;
use  Milon\Barcode\Facades\DNS1DFacade;

class adminController extends Controller
{
    public function RegisterAdmin()
    {
        $user = User::find(Auth::user()->id);
        if ($user->type == 'super_admin') {
            return view('admin.register-admin');
        }
        return view('home');
    }

    public function SubmitRegisterAdmin(Request $request)
    {
        $user = new User();
        $user->name = $request->input('name');
        $user->email = $request->input('email');
        $user->type = $request->input('type');
        $user->password = Hash::make($request['password']);
        $user->save();

        $admin = new Admin();
        $admin->user_id = $user->id;
        $admin->phone = $request->input('phone');
        $admin->save();

        return redirect()->back()->with('success', 'Admin Added successfully');
    }

    public function admin(Request $request)
    {
        if (Auth::user()->type !== 'super_admin') {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
        $Admin = Admin::all();
        foreach ($Admin as $UserAdmin) {
            $user = User::find($UserAdmin->user_id);
            $UserAdmin->name = $user->name;
            $UserAdmin->email = $user->email;
            $UserAdmin->type = $user->type;
        }
        return view('admin.admin', compact('Admin'));
    }

    public function deleteadmin(Request $request)
    {
        Admin::find($request->get('id'))->delete();
        User::find($request->get('user_id'))->delete();
        return redirect()->back()->with('error', 'Admin deleted successfully');
    }

    public function editadmin(Request $request)
    {
        if (Auth::user()->type !== 'super_admin') {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
        $Admin = Admin::where('user_id', $request->get('id'))->first();
        $User = User::where('id', $request->get('id'))->first();
        return view('admin.editadmin', compact('Admin', 'User'));
    }

    public function SubmitEditAdmin(Request $request)
    {
        $user = User::find($request->get('id'));
        $user->name = $request->input('name');
        $user->email = $request->input('email');
        if (isset(request()->type)) {
            request()->validate([
                $user->type = $request->input('type')
            ]);
        }

        $user->save();

        $admin = Admin::find($request->get('user_id'));
        $admin->phone = $request->input('phone');
        $admin->save();
        return redirect('admin')->with('success', 'Admin Edit successfully');
    }

    public function client(Request $request)
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin') {
            $Admin = Client::with('user')->get();
            return view('client.client', compact('Admin'));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }

    public function deleteclient(Request $request)
    {
        client::find($request->get('id'))->delete();
        User::find($request->get('user_id'))->delete();
        return redirect()->back()->with('error', 'client deleted successfully');
    }

    public function editclient(Request $request)
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin') {
            $Admin = client::where('user_id', $request->get('id'))->first();
            $User = User::where('id', $request->get('id'))->first();
            return view('client.editclient', compact('Admin', 'User'));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }
    
    public function registerUser(Request $request)
    {
        $locations = Location::all();
        return view('admin.AddUser', compact('locations'));
    }
    
    public function location_prices(Request $request)
    {
        $locations = Location::all();
        $user_id = $request->id;
        $districtsPrices = DistrictsPrices::all();
        $districts = Districts::all();
        
        return view('admin.Locations_prices', compact('locations', 'user_id', 'districtsPrices', 'districts'));
    }
    
    public function cities_prices(Request $request)
    {
        $cities = City::where('locations', $request->id)->get();
        $user_id = $request->user_id;

        return view('admin.cities_prices', compact('cities', 'user_id'));
    }
    
    public function districts_prices(Request $request)
    {
        $districts = Districts::where('city_id', $request->id)->get();
        $userDistricts = DistrictsPrices::where('user_id', $request->user_id)->get();

        // return $userDistricts;
        $user_id = $request->user_id;
        return view('admin.districts_prices', compact('districts', 'user_id', 'userDistricts'));
    }
    
    public function submitDistrictsPrices(Request $request)
    {

        foreach($request->all() as $key => $value) {

            if ($key == 0) {
                continue;
            }
            
            $districtsPrciese = DistrictsPrices::updateOrCreate(
                ['user_id' =>  $request->user_id, 'district_id' => $key],
                ['price' => $value]
            );
        }
        
        return back();
    }
    
     public function RegisterByAdmin(Request $request)
    {
        $status = 'pending';
        if (Auth::user()) {
            if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin') {
                $status = 'approved';
            }
        }
        $user = new User();
        $user->name = $request->get('name');
        $user->email = $request->get('email');
        $user->phone = $request->get('phone');
        $user->type = $request->get('type');
        $user->password = Hash::make($request->get('password'));
        $user->save();

        if ($request->get('type') == 'client') {
            $client = new Client();
            $client->user_id = $user->id;
            $client->address = $request->get('address');
            $client->status  =  'approved';
            $client->amman   =   $request->amman;
            $client->south   =   $request->south;
            $client->north   =   $request->north;
            $client->middle  =   $request->middle;
            $client->ghour   =   $request->ghour;
            $client->other   =   $request->other;
            $client->save();
        } 
        elseif ($request->get('type') == 'driver') {
            $driver = new Driver();
            $driver->user_id = $user->id;
            $driver->address = $request->get('address');
            $driver->status =  $status;
            $driver->save();
        }
        
        return redirect()->route('location-prices', $user->id);
    }

    public function SubmitEditall(Request $request)
    {
        $user = User::find($request->user_id);
        $user->name   =  $request->name;
        $user->email  =  $request->email;
        $user->phone  =  $request->phone;
        if (isset(request()->type)) {
            request()->validate([
                $user->type = $request->type
            ]);
        }
        $user->save();

        if ($request->type == 'client') {
            $admin = Client::find($request->id);
            $admin->address  =   $request->address;
            $admin->status   =  'approved';
            $admin->save();
            return redirect()->route('location-prices', $user->id);
            // return redirect('client')->with('success', 'Client Edit successfully');
        } elseif ($request->type == 'driver') {
            $admin = Driver::find($request->id);
            $admin->address =  $request->address;
            $admin->status  =  $request->status;
            $admin->save();
            return redirect()->route('location-prices', $user->id);
            // return redirect('driver')->with('success', 'Driver Edit successfully');
        } elseif ($request->type == 'finance') {
            $admin = Finance::find($request->get('id'));
            $admin->address =  $request->address;
            $admin->status  =  $request->status;
            $admin->save();

            return redirect('finance')->with('success', 'Finance Edit successfully');
        } elseif ($request->type == 'dispatcher') {
            $admin = Dispatcher::find($request->get('id'));
            $admin->address =  $request->address;
            $admin->status  =  $request->status;
            $admin->save();

            return redirect('dispatcher')->with('success', 'Dispatcher Edit successfully');
        } elseif ($request->type == 'monitor') {
            $admin = Monitor::find($request->id);
            $admin->address =  $request->address;
            $admin->status  =  $request->status;
            $admin->save();

            return redirect('monitor')->with('success', 'Monitor Edit successfully');
        }
    }

    public function driver(Request $request)
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin') {
            $Admin = Driver::with('user')->get();
            // return $Admin;
            return view('driver.driver', compact('Admin'));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }
    
    public function pickedup(Request $request)
    {
        
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin') {
            $Admin = Pickedup::with('user')->get();
            // return $Admin;
            return view('pickedup.pickedup', compact('Admin'));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }

    public function editdriver(Request $request)
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin') {
            $Admin = driver::where('user_id', $request->get('id'))->first();
            $User = User::where('id', $request->get('id'))->first();
            return view('driver.editDriver', compact('Admin', 'User'));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }

    public function deletedriver(Request $request)
    {
        driver::find($request->get('id'))->delete();
        User::find($request->get('user_id'))->delete();
        return redirect()->back()->with('error', 'Driver deleted successfully');
    }

    public function finance(Request $request)
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin') {
            $Admin = Finance::where('status', 'approved')->get();
            foreach ($Admin as $UserAdmin) {
                $user = User::find($UserAdmin->user_id);
                $UserAdmin->name = $user->name;
                $UserAdmin->email = $user->email;
                $UserAdmin->type = $user->type;
            }
            return view('finance.finance', compact('Admin'));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }

    public function editfinance(Request $request)
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin') {
            $Admin = Finance::where('user_id', $request->get('id'))->first();
            $User = User::where('id', $request->get('id'))->first();
            return view('finance.editFinance', compact('Admin', 'User'));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }

    public function deletefinance(Request $request)
    {
        Finance::find($request->get('id'))->delete();
        User::find($request->get('user_id'))->delete();
        return redirect()->back()->with('error', 'Finance deleted successfully');
    }

    public function dispatcher(Request $request)
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin') {
            $Admin = Dispatcher::with('user')->get();
            return view('dispatcher.dispatcher', compact('Admin'));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }

    public function editdispatcher(Request $request)
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin') {
            $Admin = dispatcher::where('user_id', $request->get('id'))->first();
            $User = User::where('id', $request->get('id'))->first();
            return view('dispatcher.editDispatcher', compact('Admin', 'User'));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }

    public function deletedispatcher(Request $request)
    {
        dispatcher::find($request->get('id'))->delete();
        User::find($request->get('user_id'))->delete();
        return redirect()->back()->with('error', 'dispatcher deleted successfully');
    }

    public function monitor(Request $request)
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin') {
            $Admin = monitor::with('user')->get();
            return view('monitor.monitor', compact('Admin'));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }

    public function editmonitor(Request $request)
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin') {
            $Admin = monitor::where('user_id', $request->get('id'))->first();
            $User = User::where('id', $request->get('id'))->first();
            return view('monitor.editMonitor', compact('Admin', 'User'));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }

    public function deletedmonitor(Request $request)
    {
        monitor::find($request->get('id'))->delete();
        User::find($request->get('user_id'))->delete();
        return redirect()->back()->with('error', 'monitor deleted successfully');
    }

    public function addlocation(Request $request) //open page
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin') {
            return view('admin.Locations');
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }

    public function SubmitLocation(Request $request) //add function
    {
        $Location = new Location();
        $Location->Region = $request->Region;
        $Location->save();
        return redirect()->back()->with('success', 'Location Added successfully');
    }

    public function location(Request $request) //view all locations
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin') {
            $Location = Location::all();
            $City = City::all();
            $Districts = Districts::all();
            return view('admin.ViewLocations', compact('Location','City','Districts'));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }

    public function deleteLocation(Request $request)
    {
        Location::find($request->get('id'))->delete();
        return redirect()->back()->with('error', 'Location deleted successfully');
    }

    public function editLocation(Request $request)
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin') {
            $Location = Location::where('id', $request->get('id'))->first();
            return view('admin.EditLocation', compact('Location'));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }

    public function SubmitEditLocation(Request $request)
    {
        $Location1 = Location::where('id', $request->get('id'))->first();
        $Location->Region = $request->Region;
        $Location1->save();
        $Location = Location::all();
        $success = 'Location Editing successfully';
        return view('admin.ViewLocations', compact('Location', 'success'));
    }

    public function viewAllOrders(Request $request)
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin') {
            $Driver = Driver::with('user')->where('status','approved')->get();
            $Order = Order::with('assigned_order')->orderBy('id', 'desc')->get();
            $itemP = array();
            $deliveryP = array();
            $totalP = array();
            foreach($Order as $order){
                array_push($itemP,$order->itemPrice);
                array_push($deliveryP,$order->deliveryPrice);
                array_push($totalP,$order->totalPrice);
            }
            $itemPrice = array_sum($itemP);
            $deliveryPrice = array_sum($deliveryP);
            $totalPrice = array_sum($totalP);
            if ($request->has('city') && isset($request->city)) {
                $Order = $Order->whereIn('city' , $request->city);
            }
            $City = City::all();
            return view('admin.viewAllOrders', compact('Order','City','Driver','itemPrice','deliveryPrice','totalPrice'));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }

    public function addOrder(Request $request)
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin') {
            $locations = Location::all();
            $City = City::all();
            $Districts = Districts::all();
            $clients = client::with('user')->get();
            return view('admin.addOrder', compact(['clients', 'locations','City','Districts']));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }
    
    public function getcity(Request $request)
    {
        $loc = $request->_token;
        $cities = City::where('locations', $loc)->get();
        // $location = Location::find('Region',$loc);
        return $cities;
    }
    
    public function getdistricts(Request $request)
    {
        $loc = $request->_token;
        $distrcits = Districts::where('city_id', $loc)->get();
        return $distrcits;
    }
    
    public function getUserDistrict(Request $request)
    {
        $loc = $request->_token;
        
        $distrcitsPrices = DB::table('districts')
            ->leftjoin('districts_prices as d', 'd.district_id', '=', 'districts.id')
            ->where('districts.city_id', $loc)
            ->where('d.user_id', $request->user_id)
            ->select('districts.id', 'districts.name','d.price')
            ->get();
            
        if (count($distrcitsPrices) > 0) {
            return $distrcitsPrices;   
        } else {
            $distrcits = Districts::with('districts_prices')->where('city_id', $loc)->select('id', 'name')->get();
            return $distrcits;   
        }
    }

    public function getDeliveryPrice(Request $request)
    {
        $client = Client::find($request->client);
        $delivery_price = DistrictsPrices::where('user_id', $client->user_id)->where('district_id', $request->district)->select('price')->first();
        
        return $delivery_price;
    }
    
    public function getClientDeliveryPrice(Request $request)
    {
        $delivery_price = DistrictsPrices::where('user_id', Auth::id())->where('district_id', $request->district)->select('price')->first();
        
        return $delivery_price;
    }

    public function submitAddOrder(Request $request)
    {
        $Order = new Order();
        $client = Client::with('user')->where('id', $request->client_id)->first();

        $Order->status           =  'Pending';
        $Order->client_id        =  $client->id;
        $Order->SenderNumber     =  $client->user->phone;
        $Order->SenderName       =  $client->user->name;
        $Order->RecipientNumber  =  $request->Recipientnumber;
        $Order->RecipientName    =  $request->Recipientname;
        $Order->city             =  $request->city;
        $Order->districts        =  $request->district;
        $Order->locations        =  $request->location;
        $Order->RecipientAddress =  $request->Recipientaddress;
        $Order->itemPrice        =  $request->itemprice;
        $Order->deliveryPrice    =  $request->deliveryprice;
        $Order->totalPrice       =  $request->totalprice;
        $Order->lat              =  0.000000;
        $Order->lon              =  0.000000;
        $Order->notes            =  $request->notes;
        $Order->barcode          =  rand(1000, 9999);
        $Order->save();
        
        $dispatchers = Dispatcher::with('user')->get();
        foreach($dispatchers as $dispatcher) {
            if (isset($dispatcher->user)) {
                $message = 'There is a new order !'; 
                $title = 'Hello '.$dispatcher->user->name;
                $player_id = $dispatcher->user->player_id;
                if (isset($dispatcher->user->player_id) && $player_id != '') {
                    app('App\Http\Controllers\NotificationController')->sendNtoification($player_id, $message, $title);
                }
            }
        }

        $notifications = new Notifications();
        $notifications->order_id = $Order->id;
        $notifications->message = " New Order need to Assign !.";
        $notifications->is_seen = 0;
		$notifications->save();
        return redirect()->back()->with('success', 'Order Added Successfully ');
    }

    public function editOrder(Request $request)
    {
        if (Auth::user()->type == 'super_admin' || Auth::user()->type == 'admin' || Auth::user()->type == 'client') {
            $user = User::with('client')->where('id', Auth::user()->id)->first();
            $locations = Location::all();
            $order = Order::find($request->id);
            return view('client.Order',compact(['locations', 'user', 'order']));
        } else {
            return '404 YOU DONT HAVE ACCESS TO THIS ROUTE';
        }
    }

    public function updateOrder(Request $request)
    {
            $Order = Order::find($request->id);            
            $client = Client::with('user')->where('id', $request->client_id)->first();
            $Order->status           =  'Pending';
            $Order->client_id        =  $client->id;
            $Order->SenderNumber     =  $client->user->phone;
            $Order->SenderName       =  $client->user->name;
            $Order->RecipientNumber  =  $request->Recipientnumber;
            $Order->RecipientName    =  $request->Recipientname;
            $Order->city             =  $request->city;
            $Order->districts        =  $request->district;
            $Order->locations        =  $request->location;
            $Order->RecipientAddress =  $request->Recipientaddress;
            $Order->itemPrice        =  $request->itemprice;
            $Order->deliveryPrice    =  $request->deliveryprice;
            $Order->totalPrice       =  $request->totalprice;
            $Order->lon              =  $request->lon;
            $Order->lat              =  $request->lat;
            $Order->notes            =  $request->notes;
            $Order->save();
            return redirect()->back()->with('success', 'Order Edit Successfully');
    }
    
        public function ViewDetailsOrder(Request $request)
        {
        $Order = Order::find($request->id);   
        $Admin = Client::where('id',$Order->client_id)->with('user')->first();//Get Client by order
        $assignOrders = AssignOrders::where('Order_id',$Order->id)->first();
        if (isset($assignOrders->Driver_id)) {
            $Driver = Driver::where('id',$assignOrders->Driver_id)->with('user')->first();
            $districtsPrices = DistrictsPrices::where('user_id',$Driver->user_id)->where('district_id',$Order->districts)->first();
            $Totalnet = (int)$Order->totalPrice - $districtsPrices->price;//الصافي بعد خصم سعر السائق
        } else {
            $Driver = null;
            $districtsPrices = null;
            $Totalnet = null;
        }
        
        return view('admin.View-Details-Order', compact('Admin','Order','Driver','assignOrders','Totalnet','districtsPrices'));
        }
        
        public function EditMyProfile(Request $request){
            $address = "";
        if (Auth::user()->type == 'client') {
            $User = User::where('id',$request->id)->with('client')->first();
            $address = $User->client->address;

        } elseif (Auth::user()->type == 'driver') {
            $User = User::where('id',$request->id)->with('driver')->first();
            $address = $User->driver->address;

        } elseif (Auth::user()->type == 'finance') {
            $User = User::where('id',$request->id)->with('finance')->first();
            $address = $User->finance->address;

        } elseif (Auth::user()->type == 'dispatcher') {
            $User = User::where('id',$request->id)->with('dispatcher')->first();
            $address = $User->dispatcher->address;

        } elseif (Auth::user()->type == 'monitor') {
            $User = User::where('id',$request->id)->with('monitor')->first();
            $address = $User->monitor->address;

        } elseif (Auth::user()->type == 'admin') {
            $User = User::where('id',$request->id)->with('admin')->first();
            $address = "";

        }elseif (Auth::user()->type == 'super_admin') {
            $User = User::where('id',$request->id)->with('admin')->first();
            $address = "";

        }
            return view('admin.EditMyProfile',compact('User','address'));
        }
        
        public function SubmitEditallprofile(Request $request)
        {
            $rules = [
                'email' => 'required|email|max:255',
            ];
    
            $emailRules = [
                'email' => 'unique:users',
            ];
    
            $validator = Validator::make($request->all(), $rules);
            $UniqueEmailValidator = Validator::make($request->all(), $emailRules);
            if ($validator->fails()) {
                 return back()->with('error', 'Email should be in a valid Format Ex: email@something.something');
            } elseif ($UniqueEmailValidator->fails()) {
                return back()->with('error', 'Email Already Exist');
            }
        
            $user = User::where('id', Auth::id())->first();
            if ($request->name != '' && $request->name != $user->name) {
                $user->name   =  $request->name;
            }
            if ($request->email != '' && $request->email != $user->email) {
                $user->email   =  $request->email;
            }
            if ($request->phone != '' && $request->phone != $user->phone) {
                $user->phone   =  $request->phone;
            }
            $user->save();
                
            if (Auth::user()->type == 'client') {
                $client = Client::where('user_id',$user->id)->first();
                $client->address = $request->address;
                if ($request->address != '' && $request->address != $client->address) {
                    $client->address   =  $request->address;
                }
                $client->save();
    
            } elseif (Auth::user()->type == 'driver') {
                $driver = Driver::where('user_id',$user->id)->first();
                if ($request->address != '' && $request->address != $driver->address) {
                    $driver->address   =  $request->address;
                }
                $driver->save();
    
            } elseif (Auth::user()->type == 'finance') {
                $finance = Finance::where('user_id',$user->id)->first();
                if ($request->address != '' && $request->address != $finance->address) {
                    $finance->address   =  $request->address;
                }
                $finance->save();
    
            } elseif (Auth::user()->type == 'dispatcher') {
                $dispatcher = Dispatcher::where('user_id',$user->id)->first();
                if ($request->address != '' && $request->address != $dispatcher->address) {
                    $dispatcher->address   =  $request->address;
                }
                $dispatcher->save();
                
            } elseif (Auth::user()->type == 'monitor') {
                $monitor = Monitor::where('user_id',$user->id)->first();
                if ($request->address != '' && $request->address != $monitor->address) {
                    $monitor->address   =  $request->address;
                }
                $monitor->save();
    
            }
            return redirect()->back()->with('success', 'Editing Successfully');
        }
        
}