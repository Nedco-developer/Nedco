<?php
namespace App\Http\Controllers;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\Admin;
use App\Models\User;
use App\Models\Client;
use App\Models\Dispatcher;
use App\Models\Finance;
use App\Models\Monitor;
use App\Models\Driver;
use App\Models\Location;
use App\Models\Order;
use App\Models\City;
use App\Models\Districts;
use App\Models\DistrictsPrices;
use App\Models\AssignOrders;
use App\Models\FinancialAccounts;
use DB;

class FinancialAccountsController extends Controller
{
    
    public function FinancialAccountsPage(Request $request){
        $client = Client::where('status','approved')->with('user')->get();
        $driver = Driver::where('status','approved')->with('user')->get();
        return view('FinancialAccounts.FinancialAccounts' , compact('client','driver'));
    }

    public function Accounts(Request $request){
        $Accounts = FinancialAccounts::where('user_id',$request->get('user_id'))->get();
        $price = array();
            foreach($Accounts as $accounts){
                array_push($price,$accounts->price);
            }
        $TotalPrice = array_sum($price);
        $Orders = array();
        $ItemPrice = array();
        $DeliveryPrice = array();
        $TotalPricee = array();
            if($request->get('name') == 'driver'){
                $Admin = Driver::where('user_id',$request->get('user_id'))->with('user')->first();
                $AssignOrders = AssignOrders::where('Driver_id',$Admin->id)->get();
                foreach($AssignOrders as $assignorders)
                {
                    $Order = Order::where('id',$assignorders->Order_id)->where('status','!=','Pending')->where('status','!=','out for delivery')->get();
                        foreach($Order as $order)
                        {
                            $DistrictsPrices = DistrictsPrices::where('district_id',$order->districts)->first();
                            array_push($Orders,$order);
                            array_push($ItemPrice,$order->itemPrice);
                            array_push($DeliveryPrice,$DistrictsPrices->price);
                            array_push($TotalPricee,$order->totalPrice);
                        }
                }
            }elseif($request->get('name') == 'client'){
                $Admin = Client::where('user_id',$request->get('user_id'))->with('user')->first();
                $Order = Order::where('client_id' , $Admin->id)->where('status','!=','Pending')->where('status','!=','out for delivery')->get();
                foreach($Order as $order)
                {
                    array_push($Orders,$Order);
                    array_push($ItemPrice,$order->itemPrice);
                    array_push($DeliveryPrice,$order->deliveryPrice);
                    array_push($TotalPricee,$order->totalPrice);
                }
            }
        $item = array_sum($ItemPrice);
        $delivery = array_sum($DeliveryPrice);
        $total = $item + $delivery;
        return view('FinancialAccounts.Accounts' , compact('item','Orders','delivery','total','Admin','TotalPrice'));
    }
    
    public function SaveAccounts(Request $request){
        $Accounts = new FinancialAccounts();
        $Accounts->user_id = $request->get('user_id');
        $Accounts->price = '-'.$request->get('Price');
        $Accounts->save();
        return redirect('FinancialAccounts')->with('success', 'The account has been modified successfully');
    }

}