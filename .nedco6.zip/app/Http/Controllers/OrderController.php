<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Location;
use App\Models\Order;
use App\Imports\OrdersImport;
use Excel;

class OrderController extends Controller
{
    public function confirmLocation(Request $request)
    {
        $oid = $request->oid;
        $order = Order::find($oid);
        
        $lat = $order->lat;
        $lon = $order->lon;
        
        return view('map.map', compact(['lat', 'lon', 'oid']));
    }
    
    public function changeOrderLocation(Request $request)
    {
        $lat = $request->lat;
        $lon = $request->lon;
        $oid = $request->oid;
        
        $order = Order::find($oid);
        $order->lat = $request->lat;
        $order->lon = $request->lon;
        $order->save();
        
        return redirect()->route('/');
    }

    public function addFromExel(Request $request)
    {
        return view('admin.addOrdersExel');
    }

    public function importExcel(Request $request) 
    {
        Excel::import(new OrdersImport, $request->file('excel')->store('temp'));
        return back()->with('success', 'Orders Added');
    }
}