<?php
namespace App\Http\Controllers;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\Admin;
use App\Models\User;
use App\Models\Client;
use App\Models\Dispatcher;
use App\Models\Finance;
use App\Models\Monitor;
use App\Models\Driver;
use App\Models\Location;
use App\Models\Order;
use App\Models\City;
use App\Models\Districts;
use App\Models\DistrictsPrices;
use App\Models\AssignOrders;
use DB;

class ReportController extends Controller
{
    public function Reports(){
        // Dailly
        $DaillyOrder = Order::where('created_at' , 'LIKE', '%'.date('Y-m-d').'%')->where('status','!=','out for delivery')->where('status','!=','pending')->get();
        $DaillyItemPrice = array();
        $DaillyDeliveryPrice = array();
        $DaillyTotalPrice = array();
        $driverID = array();
        $DistrictsID = array();
        foreach($DaillyOrder as $Dailly)
        {
            array_push($DaillyItemPrice,$Dailly->itemPrice);
            array_push($DaillyDeliveryPrice,$Dailly->deliveryPrice);
            array_push($DaillyTotalPrice,$Dailly->totalPrice);
            array_push($DistrictsID,$Dailly->districts);
            $assignOrders = AssignOrders::where('Order_id',$Dailly->id)->get();
                foreach($assignOrders as $Orders)
                {
                    $driverD = Driver::where('id',$Orders->Driver_id)->with('user')->first();
                    array_push($driverID,$driverD->user_id);
                }
        }
        $districtsPrices = DistrictsPrices::whereIn('user_id',$driverID)->whereIn('district_id',$DistrictsID)->pluck('price')->sum();
        
        $OrdersD = $DaillyOrder;
        $DaillyItem = array_sum($DaillyItemPrice);
        $DaillyDelivery = array_sum($DaillyDeliveryPrice);
        $DaillyTotal = array_sum($DaillyTotalPrice);
        $TotalDaillyDriver = $districtsPrices;
        $totalDaillyNet = $DaillyDelivery - $TotalDaillyDriver;
        
        // End Dailly
//--------------------------------------------------------------------------------------------------------------------
        // Weekly
        $WeeklyOrder = Order::where('created_at' ,'>=',date('Y-m-d',strtotime('-7 days')))->where('status','!=','out for delivery')->where('status','!=','pending')->get();
        $WeeklyItemPrice = array();
        $WeeklyDeliveryPrice = array();
        $WeeklyTotalPrice = array();
        $driverID = array();
        $DistrictsID = array();
        foreach($WeeklyOrder as $Weekly)
        {
            array_push($WeeklyItemPrice,$Weekly->itemPrice);
            array_push($WeeklyDeliveryPrice,$Weekly->deliveryPrice);
            array_push($WeeklyTotalPrice,$Weekly->totalPrice);
            array_push($DistrictsID,$Weekly->districts);
            $assignOrders = AssignOrders::where('Order_id',$Weekly->id)->get();
                foreach($assignOrders as $Orders)
                {
                    $driverW = Driver::where('id',$Orders->Driver_id)->with('user')->first();
                    array_push($driverID,$driverW->user_id);
                }
        }
        $districtsPricesW = DistrictsPrices::whereIn('user_id',$driverID)->whereIn('district_id',$DistrictsID)->pluck('price')->sum();
        
        $OrdersW = $WeeklyOrder;
        $WeeklyItem = array_sum($WeeklyItemPrice);
        $WeeklyDelivery = array_sum($WeeklyDeliveryPrice);
        $WeeklyTotal = array_sum($WeeklyTotalPrice);
        $TotalWeeklyDriver = $districtsPricesW;
        $totalWeeklyNet = $WeeklyDelivery - $TotalWeeklyDriver;
        // End Weekly
//--------------------------------------------------------------------------------------------------------------------
        // month
        $monthlyOrder = Order::where('created_at', '>=', date('Y-m-d',strtotime('-1 month')))->where('status','!=','out for delivery')->where('status','!=','pending')->get();
        $monthlyItemPrice = array();
        $monthlyDeliveryPrice = array();
        $monthlyTotalPrice = array();
        $driverID = array();
        $DistrictsID = array();
        foreach($monthlyOrder as $monthly)
        {
            array_push($monthlyItemPrice,$monthly->itemPrice);
            array_push($monthlyDeliveryPrice,$monthly->deliveryPrice);
            array_push($monthlyTotalPrice,$monthly->totalPrice);
            array_push($DistrictsID,$monthly->districts);
            $assignOrders = AssignOrders::where('Order_id',$monthly->id)->get();
                foreach($assignOrders as $Orders)
                {
                    $driverM = Driver::where('id',$Orders->Driver_id)->with('user')->first();
                    array_push($driverID,$driverM->user_id);
                }
        }
        $districtsPricesM = DistrictsPrices::whereIn('user_id',$driverID)->whereIn('district_id',$DistrictsID)->pluck('price')->sum();
        $OrdersM = $monthlyOrder;
        $monthlyItem = array_sum($monthlyItemPrice);
        $monthlyDelivery = array_sum($monthlyDeliveryPrice);
        $monthlyTotal = array_sum($monthlyTotalPrice);
        $TotalmonthlyDriver = $districtsPricesM;
        $totalmonthlyNet = $monthlyDelivery - $TotalmonthlyDriver;
        // End month
//--------------------------------------------------------------------------------------------------------------------
        // yearly
        $yearlyOrder = Order::where('created_at' , '>=' ,date('Y-m-d',strtotime('-1 yearly')))->where('status','!=','out for delivery')->where('status','!=','pending')->get();
        $yearlyItemPrice = array();
        $yearlyDeliveryPrice = array();
        $yearlyTotalPrice = array();
        $driverID = array();
        $DistrictsID = array();
        foreach($yearlyOrder as $yearly)
        {
            array_push($yearlyItemPrice,$yearly->itemPrice);
            array_push($yearlyDeliveryPrice,$yearly->deliveryPrice);
            array_push($yearlyTotalPrice,$yearly->totalPrice);
            array_push($DistrictsID,$yearly->districts);
            $assignOrders = AssignOrders::where('Order_id',$yearly->id)->get();
                foreach($assignOrders as $Orders)
                {
                    $driverY = Driver::where('id',$Orders->Driver_id)->with('user')->first();
                    array_push($driverID,$driverY->user_id);
                }
        }
        $districtsPricesY = DistrictsPrices::whereIn('user_id',$driverID)->whereIn('district_id',$DistrictsID)->pluck('price')->sum();
        
        $OrdersY = $yearlyOrder;
        $yearlyItem = array_sum($yearlyItemPrice);
        $yearlyDelivery = array_sum($yearlyDeliveryPrice);
        $yearlyTotal = array_sum($yearlyTotalPrice);
        $TotalyearlyDriver = $districtsPricesY;
        $totalyearlyNet = $yearlyDelivery - $TotalyearlyDriver;
        // End yearly
        // return $OrdersD;
        return view('Reports.Admin_Reports',compact('OrdersD','DaillyItem','DaillyDelivery','DaillyTotal','TotalDaillyDriver','totalDaillyNet','OrdersW','WeeklyItem','WeeklyDelivery','WeeklyTotal','TotalWeeklyDriver','totalWeeklyNet','OrdersM','monthlyItem','monthlyDelivery','monthlyTotal','TotalmonthlyDriver','totalmonthlyNet','OrdersY','yearlyItem','yearlyDelivery','yearlyTotal','TotalyearlyDriver','totalyearlyNet'));
    }
    
    public function Search(Request $request){
        $yearlyOrder = [];
        $allOrders = Order::where('status','!=','out for delivery')->where('status','!=','pending')->get();
        $yearlyItemPrice = array();
        $yearlyDeliveryPrice = array();
        $yearlyTotalPrice = array();
        $driverID = array();
        $DistrictsID = array();
        foreach($allOrders as $yearly)
        {
            if (date("Y-m-d", strtotime($yearly->created_at)) >= date($request->FromDate) && date("Y-m-d", strtotime($yearly->created_at)) <= date($request->ToDate)) {
                array_push($yearlyOrder,$yearly);
            }
        }
        foreach($yearlyOrder as $yearly)
        {
            array_push($yearlyItemPrice,$yearly->itemPrice);
            array_push($yearlyDeliveryPrice,$yearly->deliveryPrice);
            array_push($yearlyTotalPrice,$yearly->totalPrice);
            array_push($DistrictsID,$yearly->districts);
            $assignOrders = AssignOrders::where('Order_id',$yearly->id)->get();
                foreach($assignOrders as $Orders)
                {
                    $driverY = Driver::where('id',$Orders->Driver_id)->with('user')->first();
                    array_push($driverID,$driverY->user_id);
                }
        }
        $districtsPricesY = DistrictsPrices::whereIn('user_id',$driverID)->whereIn('district_id',$DistrictsID)->pluck('price')->sum();
        
        $OrdersY = $yearlyOrder;
        $yearlyItem = array_sum($yearlyItemPrice);
        $yearlyDelivery = array_sum($yearlyDeliveryPrice);
        $yearlyTotal = array_sum($yearlyTotalPrice);
        $TotalyearlyDriver = $districtsPricesY;
        $totalyearlyNet = $yearlyDelivery - $TotalyearlyDriver;

        return array('yearlyOrder' => $yearlyOrder,'yearlyItem' => $yearlyItem, 'yearlyDelivery' => $yearlyDelivery,'yearlyTotal' => $yearlyTotal,'TotalyearlyDriver' => $TotalyearlyDriver,'totalyearlyNet' => $totalyearlyNet);
    }

}