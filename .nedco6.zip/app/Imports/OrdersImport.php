<?php

namespace App\Imports;

use App\Models\Order;
use App\Models\Client;
use App\Models\User;
use App\Models\Districts;
use App\Models\DistrictsPrices;
use App\Models\Location;
use Maatwebsite\Excel\Concerns\ToModel;

class OrdersImport implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        $user = User::where('phone', $row[2])->first();
        $districts = Districts::where('name', $row[6])->first();
        $location = Location::where('Region', $row[7])->first();
        $client = Client::where('user_id', $user->id)->first();
        $delivery_price = DistrictsPrices::where('user_id', $client->user_id)->where('district_id', $districts->id)->select('price')->first();
        $total_price =  (float)$delivery_price->price + (float)$row[9];

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, "https://maps.googleapis.com/maps/api/geocode/json?address=zarqa,new%20zarqa&key=AIzaSyD-NF4wMIb4TcsnH1Y9tBklUK-BRX5Pk8U");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_ENCODING, "");
        curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 0);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");

        $response = curl_exec($ch);
        $resJson = json_decode($response);
        $lat = $resJson->results[0]->geometry->location->lat;
        $lon = $resJson->results[0]->geometry->location->lng;

        curl_close($ch);

        return new Order([
            'status'                =>         'Pending',
            'client_id'             =>         $client->id,
            'SenderNumber'          =>         $row[0],
            'SenderName'            =>         $row[1],
            'RecipientNumber'       =>         $row[3],
            'RecipientName'         =>         $row[4],
            'city'                  =>         $row[5],
            'districts'             =>         $districts->id,
            'locations'             =>         $location->id,
            'RecipientAddress'      =>         $row[8],
            'itemPrice'             =>         $row[9],
            'deliveryPrice'         =>         $delivery_price->price,
            'totalPrice'            =>         $total_price,
            'lat'                   =>         $lat,
            'lon'                   =>         $lon,
            'notes'                 =>         $row[10],
            'barcode'               =>         rand(1000, 9999),
        ]);
    }
}
