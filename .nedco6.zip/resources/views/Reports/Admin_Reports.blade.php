@extends('layouts.dashboardApp')

@section('title', 'Orders')

@section('content')
<style>
    .table-res{
        display: block !important;
        overflow-x: auto !important;
    }
    .entity-menu>.nav-item>a.active {
            background-color: #000;
            border-bottom: 0px solid black !important;
        }
    @media only screen and (min-width: 320px) and (max-width: 568px) {
    .nav-link {
        margin-left: 1rem !important;
    }
    .side-container {
        height: 100% !important;
    }
    .side-container3 {
        height: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
        margin-left: 0rem !important;
    }
    .table-res{
        display: block !important;
        overflow-x: auto !important;
    }
}
    @media only screen and (max-width: 768px) and (max-width: 1024px) {
  .side-container {
         height: 100% !important;
    }
    .side-container3 {
        height: 100% !important;
    }
    .row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px !important;
    margin-left: 0px !important;
    }
    
    .text{
        font-size:1rem !important;
    }
    .home-form {
    width: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 1rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
    }
}
    @media only screen and (max-width: 600px) {
    .nav-link {
    margin-left: 1rem !important;
    }
  .side-container {
    height: 100% !important;
    }
    
    .side-container3 {
      height: 100% !important;
    }
    
    .row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px !important;
    margin-left: 0px !important;
    }
    
    .text{
        font-size:1rem !important;
    }
    .home-form {
    width: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 1rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
    @media only screen and (min-width: 601px) and (max-width: 768px) {
    .nav-link {
    margin-left: 1rem !important;
    }
    .side-container {
        height: 100% !important;
    }
    .side-container3 {
      height: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 0rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
    @media only screen and (max-width: 1024px) {
    .nav-link {
    margin-left: 1rem !important;
    }
    .text{
        font-size:0rem !important;
    }
    .home {
      padding: 94px 0px !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 0rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
</style>
    
    <ul class="entity-menu d-flex flex-row align-items-start entity-menu-small nav" role="tablist"
        style="margin-top: 1%;margin-left: 1%;margin-right: 1%;font-size: 21px;background-color: #ee293a;">
        <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#Yearly" style="color: #FFF;">All</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#Dailly" style="color: #FFF;">To Day</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#Weekly" style="color: #FFF;">Weekly</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#Monthly" style="color: #FFF;">Monthly</a>
        </li>
    </ul>
    
    <div style="margin-left: 1%;margin-right: 1%;" class="tab-content">
        
        <div id="Yearly" class="row justify-content-center tab-pane active">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table id="Admintable4" class="display nowrap table-res table table-condensed">
                            <thead>
                                <tr>
                                    <th>Y_id</th>
                                    <th>Y_status</th>
                                    <th>Y_payment status</th>
                                    <th>Y_city</th>
                                    <th>Y_item Price</th>
                                    <th>Y_delivery Price</th>
                                    <th>Y_total Price</th>
                                    <th>Y_notes</th>
                                </tr>
                            </thead>
                            <tbody id="yearlyBody">
                                @foreach($OrdersY as $ordersY)
                                    <tr>
                                        <td>{{ $ordersY->id }}</td>
                                        <td>{{ $ordersY->status }}</td>
                                        <td>{{ $ordersY->payment_status }}</td>
                                        <td>{{ $ordersY->city }}</td>
                                        <td>{{ $ordersY->itemPrice }}</td>
                                        <td>{{ $ordersY->deliveryPrice }}</td>
                                        <td>{{ $ordersY->totalPrice }}</td>
                                        <td>{{ $ordersY->notes }}</td>
                                    </tr>
                                @endforeach 
                            </tbody>
                            <tfoot id="yearlyFooter">
                                <tr>
                                    <th>Y_id</th>
                                    <th>Y_status</th>
                                    <th>Y_payment status</th>
                                    <th>Y_city</th>
                                    <th>Y_item Price</th>
                                    <th>Y_delivery Price</th>
                                    <th>Y_total Price</th>
                                    
                                    <th>Y_notes</th>
                                </tr>
                                <tr class="yearlyFilter">
                                    <td>yearly Item : {{ $yearlyItem }}</td>
                                    <td>yearly Delivery : {{ $yearlyDelivery }}</td>
                                    <td>yearly Total : {{ $yearlyTotal }}</td>
                                    <td>Total yearly Driver : {{ $TotalyearlyDriver }}</td>
                                    <td>total yearly Net : {{ $totalyearlyNet }}</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr class="yearlyFilter">
                                    <th></th>
                                    <th>From : <input type="date" onchange="changeto()" id="From" name="From"></th>
                                    <th></th>
                                    <th>To : <input type="date" id="To" name="To"></th>
                                    <th><a type="submit" id="Search" onclick="myFunction()" class="btn btn-success">Search</a></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="Dailly" class="row justify-content-center tab-pane fade">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table id="Admintable1" class="display nowrap table-res table table-condensed " >
                            <thead>
                                <tr>
                                    <th>id</th>
                                    <th>status</th>
                                    <th>payment status</th>
                                    <th>city</th>
                                    <th>item Price</th>
                                    <th>delivery Price</th>
                                    <th>total Price</th>
                                    
                                    <th>notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($OrdersD as $ordersD)
                                    <tr>
                                        <td>{{ $ordersD->id }}</td>
                                        <td>{{ $ordersD->status }}</td>
                                        <td>{{ $ordersD->payment_status }}</td>
                                        <td>{{ $ordersD->city }}</td>
                                        <td>{{ $ordersD->itemPrice }}</td>
                                        <td>{{ $ordersD->deliveryPrice }}</td>
                                        <td>{{ $ordersD->totalPrice }}</td>
                                        
                                        <td>{{ $ordersD->notes }}</td>
                                    </tr>
                                @endforeach 
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>id</th>
                                    <th>status</th>
                                    <th>payment status</th>
                                    <th>city</th>
                                    <th>item Price</th>
                                    <th>delivery Price</th>
                                    <th>total Price</th>
                                    
                                    <th>notes</th>
                                </tr>
                                <tr>
                                    <td>Dailly Item : {{ $DaillyItem }}</td>
                                    <td>Dailly Delivery : {{ $DaillyDelivery }}</td>
                                    <td>Dailly Total : {{ $DaillyTotal }}</td>
                                    <td>Total Dailly Driver : {{ $TotalDaillyDriver }}</td>
                                    <td>total Dailly Net : {{ $totalDaillyNet }}</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="Weekly" class="row justify-content-center tab-pane fade">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table id="Admintable2" class="display nowrap table-res table table-condensed ">
                            <thead>
                                <tr>
                                    <th>W_id</th>
                                    <th>W_status</th>
                                    <th>W_payment status</th>
                                    <th>W_city</th>
                                    <th>W_item Price</th>
                                    <th>W_delivery Price</th>
                                    <th>W_total Price</th>
                                    
                                    <th>W_notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($OrdersW as $ordersW)
                                    <tr>
                                        <td>{{ $ordersW->id }}</td>
                                        <td>{{ $ordersW->status }}</td>
                                        <td>{{ $ordersW->payment_status }}</td>
                                        <td>{{ $ordersW->city }}</td>
                                        <td>{{ $ordersW->itemPrice }}</td>
                                        <td>{{ $ordersW->deliveryPrice }}</td>
                                        <td>{{ $ordersW->totalPrice }}</td>
                                        
                                        <td>{{ $ordersW->notes }}</td>
                                    </tr>
                                @endforeach 
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>W_id</th>
                                    <th>W_status</th>
                                    <th>W_payment status</th>
                                    <th>W_city</th>
                                    <th>W_item Price</th>
                                    <th>W_delivery Price</th>
                                    <th>W_total Price</th>
                                    
                                    <th>W_notes</th>
                                </tr>
                                <tr>
                                    <td>Weekly Item : {{ $WeeklyItem }}</td>
                                    <td>Weekly Delivery : {{ $WeeklyDelivery }}</td>
                                    <td>Weekly Total : {{ $WeeklyTotal }}</td>
                                    <td>Total Weekly Driver : {{ $TotalWeeklyDriver }}</td>
                                    <td>total Weekly Net : {{ $totalWeeklyNet }}</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="Monthly" class="row justify-content-center tab-pane fade">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table id="Admintable3" class="display nowrap table-res table table-condensed " >
                            <thead>
                                <tr>
                                    <th>M_id</th>
                                    <th>M_status</th>
                                    <th>M_payment status</th>
                                    <th>M_city</th>
                                    <th>M_item Price</th>
                                    <th>M_delivery Price</th>
                                    <th>M_total Price</th>
                                    
                                    <th>M_notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($OrdersM as $ordersM)
                                    <tr>
                                        <td>{{ $ordersM->id }}</td>
                                        <td>{{ $ordersM->status }}</td>
                                        <td>{{ $ordersM->payment_status }}</td>
                                        <td>{{ $ordersM->city }}</td>
                                        <td>{{ $ordersM->itemPrice }}</td>
                                        <td>{{ $ordersM->deliveryPrice }}</td>
                                        <td>{{ $ordersM->totalPrice }}</td>
                                        
                                        <td>{{ $ordersM->notes }}</td>
                                    </tr>
                                @endforeach 
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>M_id</th>
                                    <th>M_status</th>
                                    <th>M_payment status</th>
                                    <th>M_city</th>
                                    <th>M_item Price</th>
                                    <th>M_delivery Price</th>
                                    <th>M_total Price</th>
                                    
                                    <th>M_notes</th>
                                </tr>
                                <tr>
                                    <td>monthly Item : {{ $monthlyItem }}</td>
                                    <td>monthly Delivery : {{ $monthlyDelivery }}</td>
                                    <td>monthly Total : {{ $monthlyTotal }}</td>
                                    <td>Total monthly Driver : {{ $TotalmonthlyDriver }}</td>
                                    <td>total monthly Net : {{ $totalmonthlyNet }}</td>
                                    <td></td>
                                    <td></td>
                                    <th></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>

<script type="text/javascript">
    function changeto(){
        let FromDate = document.getElementById("From").value;
        $('#To').attr("min", FromDate);
    }
    
    function myFunction(){
        let FromDate = document.getElementById("From").value;
        let ToDate = document.getElementById("To").value;
        $.ajax({
            url:"{{ route('Search') }}",
            type:'GET',
            data:{FromDate: FromDate, ToDate: ToDate},
            success:function(data){
                $('#yearlyBody').remove();
                $('#Admintable4').append('<tbody id="yearlyBody"></tbody>');
                $.each(data.yearlyOrder, function(index, value) {
                    $('#yearlyBody').append('<tr><td>'+ value.id +' </td><td>'+ value.payment_status +' </td><td>'+ value.city +' </td><td>'+ value.itemPrice +' </td><td>'+ value.deliveryPrice +' </td><td>'+ value.totalPrice +' </td><td>'+ value.status +' </td><td>'+ value.notes +' </td></tr>'); 
                });                    
                $('.yearlyFilter').remove();
                
                $('#yearlyFooter').append('<tr class="yearlyFilter"><td>yearly Item : '+  data.yearlyItem +'</td><td>yearly Delivery : '+ data.yearlyDelivery +'</td><td>yearly Total : '+ data.yearlyTotal +'</td><td>Total yearly Driver : '+ data.TotalyearlyDriver +'</td><td>total yearly Net : '+ data.totalyearlyNet +'</td><td></td><td></td><td></td></tr>');
           
                $('#yearlyFooter').append('<tr class="yearlyFilter"><th></th><th>From : <input type="date" onchange="changeto()" id="From" name="From"></th><th></th><th>To : <input type="date" id="To" name="To"></th><th><a type="submit" id="Search" onclick="myFunction()" class="btn btn-success">Search</a></th><th></th><td></td></td><td></tr>');
                
            }                        
        });
    }
    
    $(document).ready(function() {

        $('#Admintable1').DataTable({
              initComplete: function () {
                count = 0;
                this.api().columns().every( function () {
                    var title = this.header();
                    //replace spaces with dashes
                    title = $(title).html().replace(/[\W]/g, '-');
                    var column = this;
                    var select = $('<select style="width: 100% !important" id="' + title + '" class="select2" ></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                          //Get the "text" property from each selected data 
                          //regex escape the value and store in array
                          var data = $.map( $(this).select2('data'), function( value, key ) {
                            return value.text ? '^' + $.fn.dataTable.util.escapeRegex(value.text) + '$' : null;
                                     });
                          
                          //if no data selected use ""
                          if (data.length === 0) {
                            data = [""];
                          }
                          
                          //join array into string with regex or (|)
                          var val = data.join('|');
                          
                          //search for the option(s) selected
                          column
                                .search( val ? val : '', true, false )
                                .draw();
                        } );
     
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' );
                    } );
                  
                  //use column title as selector and placeholder
                  $('#' + title).select2({
                    multiple: true,
                    closeOnSelect: false,
                    placeholder: title
                  });
                  
                  //initially clear select otherwise first option is selected
                  $('.select2').val(null).trigger('change');
                } );
            },
            dom: 'lBfrtip',
            bInfo: false,
            buttons: [{
                    extend: 'pdf',
                    title: 'My Orders Report',
                    footer: true,
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    }
                },
                {
                    extend: 'excel',
                    title: 'My Orders Report',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    },
                    footer: false
                },
                {
                    extend: 'print',
                    title: 'My Orders Report',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    },
                    footer: true
                }
            ],

        });

        $('#Admintable2').DataTable({
            initComplete: function () {
                count = 0;
                this.api().columns().every( function () {
                    var title = this.header();
                    //replace spaces with dashes
                    title = $(title).html().replace(/[\W]/g, '-');
                    var column = this;
                    var select = $('<select style="width: 100% !important" id="' + title + '" class="select2" ></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                          //Get the "text" property from each selected data 
                          //regex escape the value and store in array
                          var data = $.map( $(this).select2('data'), function( value, key ) {
                            return value.text ? '^' + $.fn.dataTable.util.escapeRegex(value.text) + '$' : null;
                                     });
                          
                          //if no data selected use ""
                          if (data.length === 0) {
                            data = [""];
                          }
                          
                          //join array into string with regex or (|)
                          var val = data.join('|');
                          
                          //search for the option(s) selected
                          column
                                .search( val ? val : '', true, false )
                                .draw();
                        } );
     
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' );
                    } );
                  
                  //use column title as selector and placeholder
                  $('#' + title).select2({
                    multiple: true,
                    closeOnSelect: false,
                    placeholder: title
                  });
                  
                  //initially clear select otherwise first option is selected
                  $('.select2').val(null).trigger('change');
                } );
            },
            dom: 'lBfrtip',
            bInfo: false,
            buttons: [{
                    extend: 'pdf',
                    title: 'My Orders Report',
                    footer: true,
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    }
                },
                {
                    extend: 'excel',
                    title: 'My Orders Report',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    },
                    footer: false
                },
                {
                    extend: 'print',
                    title: 'My Orders Report',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    },
                    footer: true
                }
            ],

        });

        $('#Admintable3').DataTable({
            initComplete: function () {
                count = 0;
                this.api().columns().every( function () {
                    var title = this.header();
                    //replace spaces with dashes
                    title = $(title).html().replace(/[\W]/g, '-');
                    var column = this;
                    var select = $('<select style="width: 100% !important" id="' + title + '" class="select2" ></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                          //Get the "text" property from each selected data 
                          //regex escape the value and store in array
                          var data = $.map( $(this).select2('data'), function( value, key ) {
                            return value.text ? '^' + $.fn.dataTable.util.escapeRegex(value.text) + '$' : null;
                                     });
                          
                          //if no data selected use ""
                          if (data.length === 0) {
                            data = [""];
                          }
                          
                          //join array into string with regex or (|)
                          var val = data.join('|');
                          
                          //search for the option(s) selected
                          column
                                .search( val ? val : '', true, false )
                                .draw();
                        } );
     
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' );
                    } );
                  
                  //use column title as selector and placeholder
                  $('#' + title).select2({
                    multiple: true,
                    closeOnSelect: false,
                    placeholder: title
                  });
                  
                  //initially clear select otherwise first option is selected
                  $('.select2').val(null).trigger('change');
                } );
            },
            dom: 'lBfrtip',
            bInfo: false,
            buttons: [{
                    extend: 'pdf',
                    title: 'My Orders Report',
                    footer: true,
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    }
                },
                {
                    extend: 'excel',
                    title: 'My Orders Report',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    },
                    footer: false
                },
                {
                    extend: 'print',
                    title: 'My Orders Report',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    },
                    footer: true
                }
            ],

        });

        $('#Admintable4').DataTable({
            initComplete: function () {
                count = 0;
                this.api().columns().every( function () {
                    var title = this.header();
                    //replace spaces with dashes
                    title = $(title).html().replace(/[\W]/g, '-');
                    var column = this;
                    var select = $('<select style="width: 100% !important" id="' + title + '" class="select2" ></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                          //Get the "text" property from each selected data 
                          //regex escape the value and store in array
                          var data = $.map( $(this).select2('data'), function( value, key ) {
                            return value.text ? '^' + $.fn.dataTable.util.escapeRegex(value.text) + '$' : null;
                                     });
                          
                          //if no data selected use ""
                          if (data.length === 0) {
                            data = [""];
                          }
                          
                          //join array into string with regex or (|)
                          var val = data.join('|');
                          
                          //search for the option(s) selected
                          column
                                .search( val ? val : '', true, false )
                                .draw();
                        } );
     
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' );
                    } );
                  
                  //use column title as selector and placeholder
                  $('#' + title).select2({
                    multiple: true,
                    closeOnSelect: false,
                    placeholder: title
                  });
                  
                  //initially clear select otherwise first option is selected
                  $('.select2').val(null).trigger('change');
                } );
            },
            dom: 'lBfrtip',
            bInfo: false,
            buttons: [{
                    extend: 'pdf',
                    title: 'My Orders Report',
                    footer: true,
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    }
                },
                {
                    extend: 'excel',
                    title: 'My Orders Report',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    },
                    footer: false
                },
                {
                    extend: 'print',
                    title: 'My Orders Report',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    },
                    footer: true
                }
            ],

        });
    });
</script>
@endsection
