

<?php $__env->startSection('title', 'Locations'); ?>

<?php $__env->startSection('content'); ?>
<style>
        .entity-menu>.nav-item>a.active {
            background-color: #000;
            border-bottom: 0px solid black !important;
        }
@media  only screen and (min-width: 320px) and (max-width: 568px) {
    .nav-link {
        margin-left: 1rem !important;
    }
    .side-container {
        height: 100% !important;
    }
    .side-container3 {
        height: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
        margin-left: 0rem !important;
    }
    .table-res{
        display: block !important;
        overflow-x: auto !important;
    }
}
@media  only screen and (max-width: 768px) and (max-width: 1024px) {
  .side-container {
         height: 100% !important;
    }
    .side-container3 {
        height: 100% !important;
    }
    .row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px !important;
    margin-left: 0px !important;
    }
    
    .text{
        font-size:1rem !important;
    }
    .home-form {
    width: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 1rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
    }
}
@media  only screen and (max-width: 600px) {
    .nav-link {
    margin-left: 1rem !important;
    }
  .side-container {
    height: 100% !important;
    }
    
    .side-container3 {
      height: 100% !important;
    }
    
    .row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px !important;
    margin-left: 0px !important;
    }
    
    .text{
        font-size:1rem !important;
    }
    .home-form {
    width: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 1rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
@media  only screen and (min-width: 601px) and (max-width: 768px) {
    .nav-link {
    margin-left: 1rem !important;
    }
    .side-container {
        height: 100% !important;
    }
    .side-container3 {
      height: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 0rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
@media  only screen and (max-width: 1024px) {
    .nav-link {
    margin-left: 1rem !important;
    }
    .text{
        font-size:0rem !important;
    }
    .home {
      padding: 94px 0px !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 0rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
    </style>
    <ul class="entity-menu d-flex flex-row align-items-start entity-menu-small nav" role="tablist"
        style="margin-top: 1%;margin-left: 1%;margin-right: 1%;font-size: 21px;background-color: #ee293a;">
        <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#Region" style="color: #FFF;">Regions</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#Cities" style="color: #FFF;">Cities</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#Disrict" style="color: #FFF;">Disrict</a>
        </li>
    </ul>
    <div style="margin-left: 1%;margin-right: 1%;" class="tab-content">
        <div id="Region" class="row justify-content-center tab-pane active">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <?php if(\Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo \Session::get('error'); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(\Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo \Session::get('success'); ?>

                        </div>
                    <?php endif; ?>
                    <a class="btn btn-success" style="margin-bottom: 1rem;" href="/nedco/addlocation">Add</a>
                        <table id="Admintable" class="display nowrap table-res table table-condensed ">
        
                            <thead>
                                    <th>
                                        id
                                    </th>
                                    <th>
                                        Region
                                    </th>
                                    <th>
                                        Edit
                                    </th>
                                    <th>
                                        Delete
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($location->id); ?></td>
                                        <td><?php echo e($location->Region); ?></td>
                                        <td><a href="editLocation?id=<?php echo e($location->id); ?>"
                                            class="btn btn-primary">edit</a>
                                        </td>
                                        <td>
                                            <a href="deleteLocation?id=<?php echo e($location->id); ?>"
                                                class="btn btn-danger">delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="Cities" class="row justify-content-center tab-pane fade">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <?php if(\Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo \Session::get('error'); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(\Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo \Session::get('success'); ?>

                        </div>
                    <?php endif; ?>
                    <a class="btn btn-success" style="margin-bottom: 1rem;" href="/nedco/addCities">Add</a>
                        <table id="Admintable1" class="display nowrap table-res table table-condensed ">
        
                            <thead>
                                    <th>
                                        id
                                    </th>
                                    <th>
                                        City
                                    </th>
                                    <th>
                                        Edit
                                    </th>
                                    <th>
                                        Delete
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $City; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Cit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Cit->id); ?></td>
                                        <td><?php echo e($Cit->name); ?></td>
                                        <td><a href="editCities?id=<?php echo e($Cit->id); ?>"
                                            class="btn btn-primary">edit</a>
                                        </td>
                                        <td>
                                            <a href="deleteCities?id=<?php echo e($Cit->id); ?>"
                                                class="btn btn-danger">delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="Disrict" class="row justify-content-center tab-pane fade">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <?php if(\Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo \Session::get('error'); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(\Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo \Session::get('success'); ?>

                        </div>
                    <?php endif; ?>
                    <a class="btn btn-success" style="margin-bottom: 1rem;" href="/nedco/addDistricts">Add</a>
                        <table id="Admintable2" class="display nowrap table-res table table-condensed ">
        
                            <thead>
                                    <th>
                                        id
                                    </th>
                                    <th>
                                        Disrict
                                    </th>
                                    <th>
                                        Edit
                                    </th>
                                    <th>
                                        Delete
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disrict): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($disrict->id); ?></td>
                                        <td><?php echo e($disrict->name); ?></td>
                                        <td><a href="editDistricts?id=<?php echo e($disrict->id); ?>"
                                            class="btn btn-primary">edit</a>
                                        </td>
                                        <td>
                                            <a href="deleteDistricts?id=<?php echo e($disrict->id); ?>"
                                                class="btn btn-danger">delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
        
        
        <script>
            $(document).ready(function() {
                $('#Admintable').DataTable();
            });
             $(document).ready(function() {
                $('#Admintable1').DataTable();
            });
            $(document).ready(function() {
                $('#Admintable2').DataTable();
            });

        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/mqjaujmy/NEDCO/resources/views/admin/ViewLocations.blade.php ENDPATH**/ ?>