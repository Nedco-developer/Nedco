

<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>

    <style>
    .table-res{
        display: block !important;
        overflow-x: auto !important;
    }
        .entity-menu>.nav-item>a.active {
            background-color: #000;
            border-bottom: 0px solid black !important;
        }
@media  only screen and (min-width: 320px) and (max-width: 568px) {
    .nav-link {
        margin-left: 1rem !important;
    }
    .side-container {
        height: 100% !important;
    }
    .side-container3 {
        height: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
        margin-left: 0rem !important;
    }
    .table-res{
        display: block !important;
        overflow-x: auto !important;
    }
}
@media  only screen and (max-width: 768px) and (max-width: 1024px) {
  .side-container {
         height: 100% !important;
    }
    .side-container3 {
        height: 100% !important;
    }
    .row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px !important;
    margin-left: 0px !important;
    }
    
    .text{
        font-size:1rem !important;
    }
    .home-form {
    width: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 1rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
    }
}
@media  only screen and (max-width: 600px) {
    .nav-link {
    margin-left: 1rem !important;
    }
  .side-container {
    height: 100% !important;
    }
    
    .side-container3 {
      height: 100% !important;
    }
    
    .row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px !important;
    margin-left: 0px !important;
    }
    
    .text{
        font-size:1rem !important;
    }
    .home-form {
    width: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 1rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
@media  only screen and (min-width: 601px) and (max-width: 768px) {
    .nav-link {
    margin-left: 1rem !important;
    }
    .side-container {
        height: 100% !important;
    }
    .side-container3 {
      height: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 0rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
@media  only screen and (max-width: 1024px) {
    .nav-link {
    margin-left: 1rem !important;
    }
    .text{
        font-size:0rem !important;
    }
    .home {
      padding: 94px 0px !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 0rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
    </style>
    <ul class="entity-menu d-flex flex-row align-items-start entity-menu-small nav" role="tablist"
        style="margin-top: 1%;margin-left: 1%;margin-right: 1%;font-size: 21px;background-color: #ee293a;">
        <li class="nav-item">
            <a class="nav-link " data-toggle="tab" href="#AllOrders" style="color: #FFF;">All Orders</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#Pinding" style="color: #FFF;">Pending</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#delivered" style="color: #FFF;">delivered</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#cancelled" style="color: #FFF;">cancelled</a>
        </li>
    </ul>
    <div style="margin-left: 1%;margin-right: 1%;" class="tab-content">
        <div id="AllOrders" class="row justify-content-center tab-pane fade">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <?php if(\Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo \Session::get('success'); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <table id="Admintable1" class="display nowrap table-res table table-condensed ">
                            <thead>
                                <tr>
                                     <th>
                                        id
                                    </th>
                                    <th>
                                        Sender Name
                                    </th>
                                    <th>
                                        Sender Number
                                    </th>
                                    <th>
                                        Recipient Name
                                    </th>
                                    <th>
                                        Recipient Number
                                    </th>
                                    <th>
                                        City
                                    </th>
                                    <th>
                                        Recipient Address
                                    </th>
                                    <th>
                                        item Price
                                    </th>
                                    <th>
                                        delivery Price
                                    </th>
                                    <th>
                                        total Price
                                    </th>
                                    <th>
                                        Notes
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        View
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Order->id); ?></td>
                                        <td><?php echo e($Order->SenderName); ?></td>
                                        <td><?php echo e($Order->SenderNumber); ?></td>
                                        <td><?php echo e($Order->RecipientName); ?></td>
                                        <td><?php echo e($Order->RecipientNumber); ?></td>
                                        <td><?php echo e($Order->city); ?></td>
                                        <td><?php echo e($Order->RecipientAddress); ?></td>
                                        <td><?php echo e($Order->itemPrice); ?></td>
                                        <td><?php echo e($Order->deliveryPrice); ?></td>
                                        <td><?php echo e($Order->totalPrice); ?></td>
                                        <td><?php echo e($Order->notes); ?></td>
                                        <td><?php echo e($Order->status); ?></td>
                                        <td>
                                            <a href="ViewDetailsOrder?id=<?php echo e($Order->id); ?>"
                                            class="btn btn-primary">View</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div id="Pinding" class="row justify-content-center tab-pane active ">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div id="alert" style="display: none" class="alert alert-success"></div>
                    <div class="card-body">
                        
                        <div class="row mb-2">
                                <div class="col-md-2">
                                    <select style="width: 10rem;" required name="drivers" id="drivers" class="form-control">
                                        <?php $__currentLoopData = $Driver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Driver2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($Driver2->id); ?>"><?php echo e($Driver2->user->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-2 ml-3">
                                    <input type="date" name="delivery_date" min="<?php echo e(date('Y-m-d')); ?>" id="delivery_date">
                                </div>
                                <div class="col-md-2 ml-3">
                                    <button id="MultiAssign" class="btn btn-danger ">Assign</button>
                                </div>   
                        </div>
                        
                        <table id="Admintable2" class="display nowrap table-res table table-condensed ">
                            <thead>
                                <tr>
                                    <th>
                                        Check
                                    </th>
                                    <th>
                                        id
                                    </th>
                                    <th>
                                        Sender Name
                                    </th>
                                    <th>
                                        Sender Number
                                    </th>
                                    <th>
                                        Recipient Name
                                    </th>
                                    <th>
                                        Recipient Number
                                    </th>
                                    <th>
                                        City
                                    </th>
                                    <th>
                                        Recipient Address
                                    </th>
                                    <th>
                                        item Price
                                    </th>
                                    <th>
                                        delivery Price
                                    </th>
                                    <th>
                                        total Price
                                    </th>
                                    <th>
                                        Notes
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        Drivers
                                    </th>
                                    <th>
                                        Delivery Date
                                    </th>
                                    <th>
                                        Assign Order
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Orderpinnding; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><input class="m-1" type="checkbox" name="checkbox[]" id="checkbox" value="<?php echo e($Order->id); ?>"></td>
                                        <td><?php echo e($Order->id); ?></td>
                                        <td><?php echo e($Order->SenderName); ?></td>
                                        <td><?php echo e($Order->SenderNumber); ?></td>
                                        <td><?php echo e($Order->RecipientName); ?></td>
                                        <td><?php echo e($Order->RecipientNumber); ?></td>
                                        <td><?php echo e($Order->city); ?></td>
                                        <td><?php echo e($Order->RecipientAddress); ?></td>
                                        <td><?php echo e($Order->itemPrice); ?></td>
                                        <td><?php echo e($Order->deliveryPrice); ?></td>
                                        <td><?php echo e($Order->totalPrice); ?></td>
                                        <td><?php echo e($Order->notes); ?></td>
                                        <td><?php echo e($Order->status); ?></td>
                                        <td>
                                            <select style="width: 10rem;" required name="city" id="city_<?php echo e($Order->id); ?>" class="form-control">
                                                <?php $__currentLoopData = $Driver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Driver2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($Driver2->id); ?>"><?php echo e($Driver2->user->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>
                                        <td>
                                        <input type="date" name="delivery_date" min="<?php echo e(date('Y-m-d')); ?>" id="delivery_date_<?php echo e($Order->id); ?>">
                                        </td>
                                        <td>
                                            <button id="<?php echo e($Order->id); ?>"
                                                class="submitAssgin btn btn-danger">Assign</button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div id="delivered" class="row justify-content-center tab-pane fade">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table id="Admintable3" class="display nowrap table-res table table-condensed ">
                            <thead>
                                <tr>
                                    <th>
                                        id
                                    </th>
                                    <th>
                                        Sender Name
                                    </th>
                                    <th>
                                        Sender Number
                                    </th>
                                    <th>
                                        Recipient Name
                                    </th>
                                    <th>
                                        Recipient Number
                                    </th>
                                    <th>
                                        City
                                    </th>
                                    <th>
                                        Recipient Address
                                    </th>
                                    <th>
                                        item Price
                                    </th>
                                    <th>
                                        delivery Price
                                    </th>
                                    <th>
                                        total Price
                                    </th>
                                    <th>
                                        Notes
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Orderdelivered; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Order->id); ?></td>
                                        <td><?php echo e($Order->SenderName); ?></td>
                                        <td><?php echo e($Order->SenderNumber); ?></td>
                                        <td><?php echo e($Order->RecipientName); ?></td>
                                        <td><?php echo e($Order->RecipientNumber); ?></td>
                                        <td><?php echo e($Order->city); ?></td>
                                        <td><?php echo e($Order->RecipientAddress); ?></td>
                                        <td><?php echo e($Order->itemPrice); ?></td>
                                        <td><?php echo e($Order->deliveryPrice); ?></td>
                                        <td><?php echo e($Order->totalPrice); ?></td>
                                        <td><?php echo e($Order->notes); ?></td>
                                        <td><?php echo e($Order->status); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div id="cancelled" class="row justify-content-center tab-pane fade">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table id="Admintable4" class="display nowrap table-res table table-condensed ">
                            <thead>
                                <tr>
                                    <th>
                                        id
                                    </th>
                                    <th>
                                        Sender Name
                                    </th>
                                    <th>
                                        Sender Number
                                    </th>
                                    <th>
                                        Recipient Name
                                    </th>
                                    <th>
                                        Recipient Number
                                    </th>
                                    <th>
                                        City
                                    </th>
                                    <th>
                                        Recipient Address
                                    </th>
                                    <th>
                                        item Price
                                    </th>
                                    <th>
                                        delivery Price
                                    </th>
                                    <th>
                                        total Price
                                    </th>
                                    <th>
                                        Notes
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Ordercancelled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Order->id); ?></td>
                                        <td><?php echo e($Order->SenderName); ?></td>
                                        <td><?php echo e($Order->SenderNumber); ?></td>
                                        <td><?php echo e($Order->RecipientName); ?></td>
                                        <td><?php echo e($Order->RecipientNumber); ?></td>
                                        <td><?php echo e($Order->city); ?></td>
                                        <td><?php echo e($Order->RecipientAddress); ?></td>
                                        <td><?php echo e($Order->itemPrice); ?></td>
                                        <td><?php echo e($Order->deliveryPrice); ?></td>
                                        <td><?php echo e($Order->totalPrice); ?></td>
                                        <td><?php echo e($Order->notes); ?></td>
                                        <td><?php echo e($Order->status); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            function onClick(event) {
                var order_ids = $('input[name^=checkbox]:checked').map(function(idx, elem) {
                    return $(elem).val();
                }).get();
                console.log(order_ids);
                var driver_id = $('#drivers option:selected').val();
                var delivery_date = $('#delivery_date').val();
                let _token = '<?php echo e(csrf_token()); ?>';
                $.ajax({
                    type: "post",
                    url: '<?php echo e(route("assignMultiOrder")); ?>',
                    data: {
                        _token: _token,
                        order_ids: order_ids,
                        driver_id: driver_id,
                        delivery_date: delivery_date
                    },
                    success: function(data) {
                        console.log(data);
                        // location.reload();
                        $('#alert').css('display', 'block');
                        $('#alert').text(data)
                    }
                })
            event.preventDefault();
        }

        // attach button click listener on dom ready
        $(function() {
          $('#MultiAssign').click(onClick);
        });

            $('.submitAssgin').on('click', function() {
                var order_id = $(this).attr('id');
                var driver_id = $('#city_' + order_id).val();
                var delivery_date = $('#delivery_date_' + order_id).val();
                let _token = '<?php echo e(csrf_token()); ?>';
                $.ajax({
                    type: "post",
                    url: '<?php echo e(route("assign")); ?>',
                    data: {
                        _token: _token,
                        order_id: order_id,
                        driver_id: driver_id,
                        delivery_date: delivery_date
                    },
                    success: function(data) {
                        console.log(data);
                        location.reload();
                        $('#alert').css('display', 'block');
                        $('#alert').text(data)
                    }
                })
            });
            $('#Admintable1').DataTable({
                dom: 'lBfrtip',
                bInfo: false,
                order: [ 0, 'desc' ],
                buttons: [{
                        extend: 'pdf',
                        title: 'My Orders Report',
                        footer: true,
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,11]
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,11]
                        },
                        footer: false
                    },
                    {
                        extend: 'print',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,11]
                        },
                        footer: true
                    }
                ],

            });

            $('#Admintable2').DataTable({
                dom: 'lBfrtip',
                bInfo: false,
                buttons: [{
                        extend: 'pdf',
                        title: 'My Orders Report',
                        footer: true,
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,11]
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,11]
                        },
                        footer: false
                    },
                    {
                        extend: 'print',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,11]
                        },
                        footer: true
                    }
                ],

            });

            $('#Admintable3').DataTable({
                dom: 'lBfrtip',
                bInfo: false,
                buttons: [{
                        extend: 'pdf',
                        title: 'My Orders Report',
                        footer: true,
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        },
                        footer: false
                    },
                    {
                        extend: 'print',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        },
                        footer: true
                    }
                ],

            });

            $('#Admintable4').DataTable({
                dom: 'lBfrtip',
                bInfo: false,
                buttons: [{
                        extend: 'pdf',
                        title: 'My Orders Report',
                        footer: true,
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        },
                        footer: false
                    },
                    {
                        extend: 'print',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        },
                        footer: true
                    }
                ],

            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/mqjaujmy/NEDCO/resources/views/dispatcher/Order.blade.php ENDPATH**/ ?>