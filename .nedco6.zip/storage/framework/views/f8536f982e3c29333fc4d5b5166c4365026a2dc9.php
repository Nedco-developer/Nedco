
<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>
<br>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><?php echo e(__('Locations prices')); ?><a style="margin-left: 30rem;" href="<?php echo e(url('home')); ?>" type="submit" class="btn btn-success">Finish</a></div>

            <div class="card-body">
                <div class="form-group row" >
                    <div class="col-md-6">
                        <select name="location" id="location" class="form-control">
                            <option value=''>-- Choose Location --</option>
                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($location->id); ?>"><?php echo e($location->Region); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <select name="city" id="city" class="form-control">
                            <option value=''>-- Choose City --</option>
                        </select>
                    </div>
                </div>
                <form method="POST" action="<?php echo e(route('submitDistrictsPrices')); ?>" id="districts_id">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($user_id); ?>" name="user_id" id="user_id" />
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    $("#location").change(function(){
        var data = $(this).children("option:selected").val();
            $.ajax({
                url:"<?php echo e(route('getcity')); ?>",
                type:'GET',
                data:{_token: data},
            success:function(data){
                $('#city')
                    .find('option')
                    .remove();
                $("#city").append("<option value=''>-- Choose City --</option>");
                $.each(data, function(index, value) {
                    $("#city").append("<option value="+ value.id +" data-id=" + value.id +  ">" + value.name + "</option>");
                });
               }
        });
    });

    $("#city").change(function(){
        let data = $(this).children("option:selected").val();
        let user_id = $('#user_id').val();
            $.ajax({
                url:"<?php echo e(route('getUserDistrict')); ?>",
                type:'GET',
                data:{_token: data,user_id: user_id},
            success:function(data){
                console.log(data);
                $('.districts_form').remove();
                $.each(data, function(index, value) {
                    if (value.price == 'undefined' || value.price == null || value.price == 'null') {
                        $("#districts_id").append('<div class="form-group row districts_form"><label for="name" class="col-md-4 col-form-label text-md-right">'+ value.name +'</label><div class="col-md-6"><input type="text" class="form-control" value="" name="'+ value.id +'" ></div></div>');
                    } else {
                        $("#districts_id").append('<div class="form-group row districts_form"><label for="name" class="col-md-4 col-form-label text-md-right">'+ value.name +'</label><div class="col-md-6"><input type="text" class="form-control" value="'+ value.price +'" name="'+ value.id +'" ></div></div>');
                    }
                
                });
                $("#districts_id").append('<div class="form-group row mb-0 districts_form"><div class="col-md-6 offset-md-4"><button type="submit" class="btn btn-success">Submit</button></div></div>   ');
               }                        
        });
    });
    
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/mqjaujmy/NEDCO/resources/views/admin/Locations_prices.blade.php ENDPATH**/ ?>