

<?php $__env->startSection('title', 'Add Locations'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Add Orders From Excel')); ?></div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('importExcel')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo \Session::get('success'); ?>

                            </div>
                        <?php endif; ?>
                        <div class="form-group row">
                            <label for="type" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Excel File')); ?></label>
                            <div class="col-md-6">
                                <input id="fileSelect" name="excel" type="file" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" />
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-success">
                                    <?php echo e(__('Save')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/mqjaujmy/NEDCO/resources/views/admin/addOrdersExel.blade.php ENDPATH**/ ?>