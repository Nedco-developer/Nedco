<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/stylee.css')); ?>">
    <script src="https://code.jquery.com/jquery-2.2.4.min.js" type="text/javascript"></script>
    <title>Nedco</title>
    <link rel="icon" href="<?php echo asset('images/cropped-nedco_icon-32x32.jpg'); ?>"/>
</head>

<body style="overflow-x: hidden;">
    <div id="app" class="app">
         <nav class="navbar navbar-expand-lg navbar-light p-0">
      <div class="container">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand logo" href="<?php echo e(asset('../nedco/')); ?>" >
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="nedco logo" style="width: 12rem;">
        </a>
  
    <div class="collapse navbar-collapse navbar-links" id="navbarTogglerDemo03">
        <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <?php if(explode('=', $_SERVER['REQUEST_URI'])[0] == "/nedco/"): ?>
                <li class="nav-item active" id="Home">
                  <a class="nav-link" style="color:#ffffff"  id="Home2" href="<?php echo e(asset('../nedco/')); ?>">Home</a>
                </li>
                <li class="nav-item" id="Track" >
                  <a class="nav-link" id="Track2" href="<?php echo e(asset('track')); ?>">Track</a>
                </li>
                <li class="nav-item " id="ship" >
                  <a class="nav-link" id="ship2" href="<?php echo e(asset('CheckShappingRate')); ?>">Ship</a>
                </li>
                <li class="nav-item " id="Services">
                    <a class="nav-link"  id="Services2" href="<?php echo e(asset('Services')); ?>">Services</a>
                </li>
                <li class="nav-item " id="Clients">
                    <a class="nav-link" id="Clients2" href="<?php echo e(asset('Clients')); ?>">Clients</a>
                 </li>
                <li class="nav-item " id="Contact">
                    <a class="nav-link"  id="Contact2"  href="<?php echo e(asset('Contact')); ?>">Contact Us</a>
                 </li>
            <?php elseif(explode('=', $_SERVER['REQUEST_URI'])[0] == "/nedco/track"): ?>
                <li class="nav-item " id="Home">
                  <a class="nav-link"  id="Home2" href="<?php echo e(asset('../nedco/')); ?>">Home</a>
                </li>
                <li class="nav-item active" id="Track" >
                  <a class="nav-link" style="color:#ffffff"  id="Track2" href="<?php echo e(asset('track')); ?>">Track</a>
                </li>
                <li class="nav-item " id="ship" >
                  <a class="nav-link" id="ship2" href="<?php echo e(asset('CheckShappingRate')); ?>">Ship</a>
                </li>
                <li class="nav-item " id="Services">
                    <a class="nav-link"  id="Services2" href="<?php echo e(asset('Services')); ?>">Services</a>
                </li>
                <li class="nav-item " id="Clients">
                    <a class="nav-link"   id="Clients2" href="<?php echo e(asset('Clients')); ?>">Clients</a>
                 </li>
                <li class="nav-item " id="Contact">
                    <a class="nav-link"  id="Contact2"  href="<?php echo e(asset('Contact')); ?>">Contact Us</a>
                 </li>
            <?php elseif(explode('=', $_SERVER['REQUEST_URI'])[0] == "/nedco/CheckShappingRate"): ?>
                <li class="nav-item " id="Home">
                  <a class="nav-link"  id="Home2" href="<?php echo e(asset('../nedco/')); ?>">Home</a>
                </li>
                <li class="nav-item " id="Track" >
                  <a class="nav-link" id="Track2" href="<?php echo e(asset('track')); ?>">Track</a>
                </li>
                <li class="nav-item active" id="ship" >
                  <a class="nav-link" id="ship2" style="color:#ffffff" href="<?php echo e(asset('CheckShappingRate')); ?>">Ship</a>
                </li>
                <li class="nav-item " id="Services">
                    <a class="nav-link"  id="Services2" href="<?php echo e(asset('Services')); ?>">Services</a>
                </li>
                <li class="nav-item " id="Clients">
                    <a class="nav-link" id="Clients2" href="<?php echo e(asset('Clients')); ?>">Clients</a>
                 </li>
                <li class="nav-item " id="Contact">
                    <a class="nav-link"  id="Contact2"  href="<?php echo e(asset('Contact')); ?>">Contact Us</a>
                 </li>
            <?php elseif(explode('=', $_SERVER['REQUEST_URI'])[0] == "/nedco/Services"): ?>
                <li class="nav-item " id="Home">
                  <a class="nav-link"  id="Home2" href="<?php echo e(asset('../nedco/')); ?>">Home</a>
                </li>
                <li class="nav-item " id="Track" >
                  <a class="nav-link" id="Track2" href="<?php echo e(asset('track')); ?>">Track</a>
                </li>
                <li class="nav-item " id="ship" >
                  <a class="nav-link" id="ship2" href="<?php echo e(asset('CheckShappingRate')); ?>">Ship</a>
                </li>
                <li class="nav-item active" id="Services">
                    <a class="nav-link"  style="color:#ffffff" id="Services2" href="<?php echo e(asset('Services')); ?>">Services</a>
                </li>
                <li class="nav-item " id="Clients">
                    <a class="nav-link"  id="Clients2" href="<?php echo e(asset('Clients')); ?>">Clients</a>
                 </li>
                <li class="nav-item " id="Contact">
                    <a class="nav-link"  id="Contact2"  href="<?php echo e(asset('Contact')); ?>">Contact Us</a>
                 </li>
            <?php elseif(explode('=', $_SERVER['REQUEST_URI'])[0] == "/nedco/Clients"): ?>
                <li class="nav-item " id="Home">
                  <a class="nav-link"  id="Home2" href="<?php echo e(asset('../nedco/')); ?>">Home</a>
                </li>
                <li class="nav-item " id="Track" >
                  <a class="nav-link" id="Track2" href="<?php echo e(asset('track')); ?>">Track</a>
                </li>
                <li class="nav-item " id="ship" >
                  <a class="nav-link" id="ship2" href="<?php echo e(asset('CheckShappingRate')); ?>">Ship</a>
                </li>
                <li class="nav-item " id="Services">
                    <a class="nav-link"  id="Services2" href="<?php echo e(asset('Services')); ?>">Services</a>
                </li>
                <li class="nav-item active" id="Clients">
                    <a class="nav-link " style="color:#ffffff" id="Clients2" href="<?php echo e(asset('Clients')); ?>">Clients</a>
                 </li>
                <li class="nav-item " id="Contact">
                    <a class="nav-link"  id="Contact2"  href="<?php echo e(asset('Contact')); ?>">Contact Us</a>
                 </li>
            <?php elseif(explode('=', $_SERVER['REQUEST_URI'])[0] == "/nedco/Contact"): ?>
                <li class="nav-item " id="Home">
                  <a class="nav-link"  id="Home2" href="<?php echo e(asset('../nedco/')); ?>">Home</a>
                </li>
                <li class="nav-item " id="Track" >
                  <a class="nav-link" id="Track2" href="<?php echo e(asset('track')); ?>">Track</a>
                </li>
                <li class="nav-item " id="ship" >
                  <a class="nav-link" id="ship2" href="<?php echo e(asset('CheckShappingRate')); ?>">Ship</a>
                </li>
                <li class="nav-item " id="Services">
                    <a class="nav-link"  id="Services2" href="<?php echo e(asset('Services')); ?>">Services</a>
                </li>
                <li class="nav-item " id="Clients">
                    <a class="nav-link" id="Clients2" href="<?php echo e(asset('Clients')); ?>">Clients</a>
                 </li>
                <li class="nav-item active" id="Contact">
                    <a class="nav-link"  style="color:#ffffff" id="Contact2"  href="<?php echo e(asset('Contact')); ?>">Contact Us</a>
                 </li>
            <?php else: ?>
                <li class="nav-item " id="Home">
                  <a class="nav-link"  id="Home2" href="<?php echo e(asset('../nedco/')); ?>">Home</a>
                </li>
                <li class="nav-item " id="Track" >
                  <a class="nav-link" id="Track2" href="<?php echo e(asset('track')); ?>">Track</a>
                </li>
                <li class="nav-item " id="ship" >
                  <a class="nav-link" id="ship2" href="<?php echo e(asset('CheckShappingRate')); ?>">Ship</a>
                </li>
                <li class="nav-item " id="Services">
                    <a class="nav-link"  id="Services2" href="<?php echo e(asset('Services')); ?>">Services</a>
                </li>
                <li class="nav-item " id="Clients">
                    <a class="nav-link" id="Clients2" href="<?php echo e(asset('Clients')); ?>">Clients</a>
                 </li>
                <li class="nav-item" id="Contact">
                    <a class="nav-link"  id="Contact2"  href="<?php echo e(asset('Contact')); ?>">Contact Us</a>
                 </li>
            <?php endif; ?>
          </ul>
      <form class="form-inline my-2 mx-2  my-lg-0">
            <?php if(Auth::user()): ?>
                <a href="<?php echo e(route('home')); ?>" class="btn color my-2 my-sm-0 round-input mr-2 px-5"  type="submit">My Account</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="btn color my-2 my-sm-0 round-input px-5"  type="submit">Login</a>
            <?php endif; ?>
            
      </form>
    </div>
</div>
</nav>
    </div>
</nav>
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <section id='home2' style="height: 36rem;">
        <div style="padding-top: 13rem;">
            <div class="row" style="padding: 5rem;">
                <div class="col-md-4 col-sm-12">
                    <img src="<?php echo e(asset('images/logo-background.png')); ?>" />
                </div>
                <div class="col-md-4 col-sm-12 borderLeft">
                    <div class="col-md-1">
                        <a class="footer-nav" href="<?php echo e(asset('../nedco/')); ?>">Home</a>
                    </div>
                    <div class="col-md-1">
                       <a class="footer-nav" href="<?php echo e(asset('track')); ?>">Track</a>
                    </div>
                    <div class="col-md-1">
                       <a class="footer-nav" href="<?php echo e(asset('CheckShappingRate')); ?>">Ship</a>
                    </div>
                    <div class="col-md-1">
                       <a class="footer-nav" href="<?php echo e(asset('Services')); ?>">Services</a>
                    </div>
                    <div class="col-md-1">
                       <a class="footer-nav" href="<?php echo e(asset('Clients')); ?>">Clients</a>
                    </div>
                    <div class="col-md-1">
                        <a class="footer-nav" href="<?php echo e(asset('Contact')); ?>">Contact Us</a>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <a href="#"><img src="<?php echo e(asset('images/f-background.png')); ?>" class="float-right mb-1" alt="f-background"></a>
                    <a href="#"><img src="<?php echo e(asset('images/in-background.png')); ?>" class="float-right m-1 mb-2" alt="in-background"></a>
                </div>
            </div>
        </div>
    </section>
</body>
</html>
<?php /**PATH C:\Users\O Minus\Desktop\NedcoLaravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>