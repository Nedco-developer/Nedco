

<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>

    <style>
        .entity-menu>.nav-item>a.active {
            background-color: #000;
            border-bottom: 0px solid black !important;
        }

    </style>
    <ul class="entity-menu d-flex flex-row align-items-start entity-menu-small nav" role="tablist"
        style="margin-top: 1%;margin-left: 1%;margin-right: 1%;font-size: 21px;background-color: #ee293a;">
        <li class="nav-item">
            <a class="nav-link " data-toggle="tab" href="#AllOrders" style="color: #FFF;">All Orders</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#Pinding" style="color: #FFF;">Pending</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#delivered" style="color: #FFF;">delivered</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#cancelled" style="color: #FFF;">cancelled</a>
        </li>
    </ul>
    <div style="margin-left: 1%;margin-right: 1%;" class="tab-content">
        <div id="AllOrders" class="row justify-content-center tab-pane fade">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <?php if(\Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo \Session::get('success'); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <table id="Admintable1">
                            <thead>
                                <tr>
                                    <th>
                                        Sender Name
                                    </th>
                                    <th>
                                        Sender Number
                                    </th>
                                    <th>
                                        Recipient Name
                                    </th>
                                    <th>
                                        Recipient Number
                                    </th>
                                    <th>
                                        City
                                    </th>
                                    <th>
                                        Recipient Address
                                    </th>
                                    <th>
                                        item Price
                                    </th>
                                    <th>
                                        delivery Price
                                    </th>
                                    <th>
                                        total Price
                                    </th>
                                    <th>
                                        Notes
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Order->SenderName); ?></td>
                                        <td><?php echo e($Order->SenderNumber); ?></td>
                                        <td><?php echo e($Order->RecipientName); ?></td>
                                        <td><?php echo e($Order->RecipientNumber); ?></td>
                                        <td><?php echo e($Order->city); ?></td>
                                        <td><?php echo e($Order->RecipientAddress); ?></td>
                                        <td><?php echo e($Order->itemPrice); ?></td>
                                        <td><?php echo e($Order->deliveryPrice); ?></td>
                                        <td><?php echo e($Order->totalPrice); ?></td>
                                        <td><?php echo e($Order->notes); ?></td>
                                        <td><?php echo e($Order->status); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div id="Pinding" class="row justify-content-center tab-pane active ">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div id="alert" style="display: none" class="alert alert-success"></div>
                    <div class="card-body">
                        <table id="Admintable2" class="table table-responsive">
                            <thead>
                                <tr>
                                    <th>
                                        Sender Name
                                    </th>
                                    <th>
                                        Sender Number
                                    </th>
                                    <th>
                                        Recipient Name
                                    </th>
                                    <th>
                                        Recipient Number
                                    </th>
                                    <th>
                                        City
                                    </th>
                                    <th>
                                        Recipient Address
                                    </th>
                                    <th>
                                        item Price
                                    </th>
                                    <th>
                                        delivery Price
                                    </th>
                                    <th>
                                        total Price
                                    </th>
                                    <th>
                                        Notes
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        Drivers
                                    </th>
                                    <th>
                                        Assign Order
                                    </th>
                                    <th>
                                        Delivery Date
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Orderpinnding; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Order->SenderName); ?></td>
                                        <td><?php echo e($Order->SenderNumber); ?></td>
                                        <td><?php echo e($Order->RecipientName); ?></td>
                                        <td><?php echo e($Order->RecipientNumber); ?></td>
                                        <td><?php echo e($Order->city); ?></td>
                                        <td><?php echo e($Order->RecipientAddress); ?></td>
                                        <td><?php echo e($Order->itemPrice); ?></td>
                                        <td><?php echo e($Order->deliveryPrice); ?></td>
                                        <td><?php echo e($Order->totalPrice); ?></td>
                                        <td><?php echo e($Order->notes); ?></td>
                                        <td><?php echo e($Order->status); ?></td>
                                        <td>
                                            <select required name="city" id="city_<?php echo e($Order->id); ?>" class="form-control">
                                                <?php $__currentLoopData = $Driver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Driver2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($Driver2->id); ?>"><?php echo e($Driver2->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>
                                        <td>
                                        <input type="date" name="delivery_date" min="<?php echo e(date('Y-m-d')); ?>" id="delivery_date_<?php echo e($Order->id); ?>">
                                        </td>
                                        <td>
                                            <button id="<?php echo e($Order->id); ?>"
                                                class="submitAssgin btn btn-danger">Assign</button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div id="delivered" class="row justify-content-center tab-pane fade">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table id="Admintable3">
                            <thead>
                                <tr>
                                    <th>
                                        Sender Name
                                    </th>
                                    <th>
                                        Sender Number
                                    </th>
                                    <th>
                                        Recipient Name
                                    </th>
                                    <th>
                                        Recipient Number
                                    </th>
                                    <th>
                                        City
                                    </th>
                                    <th>
                                        Recipient Address
                                    </th>
                                    <th>
                                        item Price
                                    </th>
                                    <th>
                                        delivery Price
                                    </th>
                                    <th>
                                        total Price
                                    </th>
                                    <th>
                                        Notes
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Orderdelivered; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Order->SenderName); ?></td>
                                        <td><?php echo e($Order->SenderNumber); ?></td>
                                        <td><?php echo e($Order->RecipientName); ?></td>
                                        <td><?php echo e($Order->RecipientNumber); ?></td>
                                        <td><?php echo e($Order->city); ?></td>
                                        <td><?php echo e($Order->RecipientAddress); ?></td>
                                        <td><?php echo e($Order->itemPrice); ?></td>
                                        <td><?php echo e($Order->deliveryPrice); ?></td>
                                        <td><?php echo e($Order->totalPrice); ?></td>
                                        <td><?php echo e($Order->notes); ?></td>
                                        <td><?php echo e($Order->status); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div id="cancelled" class="row justify-content-center tab-pane fade">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table id="Admintable4">
                            <thead>
                                <tr>
                                    <th>
                                        Sender Name
                                    </th>
                                    <th>
                                        Sender Number
                                    </th>
                                    <th>
                                        Recipient Name
                                    </th>
                                    <th>
                                        Recipient Number
                                    </th>
                                    <th>
                                        City
                                    </th>
                                    <th>
                                        Recipient Address
                                    </th>
                                    <th>
                                        item Price
                                    </th>
                                    <th>
                                        delivery Price
                                    </th>
                                    <th>
                                        total Price
                                    </th>
                                    <th>
                                        Notes
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Ordercancelled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Order->SenderName); ?></td>
                                        <td><?php echo e($Order->SenderNumber); ?></td>
                                        <td><?php echo e($Order->RecipientName); ?></td>
                                        <td><?php echo e($Order->RecipientNumber); ?></td>
                                        <td><?php echo e($Order->city); ?></td>
                                        <td><?php echo e($Order->RecipientAddress); ?></td>
                                        <td><?php echo e($Order->itemPrice); ?></td>
                                        <td><?php echo e($Order->deliveryPrice); ?></td>
                                        <td><?php echo e($Order->totalPrice); ?></td>
                                        <td><?php echo e($Order->notes); ?></td>
                                        <td><?php echo e($Order->status); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {

            $('.submitAssgin').on('click', function() {
                var order_id = $(this).attr('id');
                var driver_id = $('#city_' + order_id).val();
                var delivery_date = $('#delivery_date_' + order_id).val();
                $.ajax({
                    type: "get",
                    url: '/assign?order_id=' + order_id + '&driver_id=' + driver_id + '&delivery_date=' + delivery_date,
                    success: function(data) {
                        console.log(data);
                        location.reload();
                        $('#alert').css('display', 'block');
                        $('#alert').text(data)
                    }
                })
            });
            $('#Admintable1').DataTable({
                dom: 'lBfrtip',
                bInfo: false,
                buttons: [{
                        extend: 'pdf',
                        title: 'My Orders Report',
                        footer: true,
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                        },
                        footer: false
                    },
                    {
                        extend: 'print',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                        },
                        footer: true
                    }
                ],

            });

            $('#Admintable2').DataTable({
                dom: 'lBfrtip',
                bInfo: false,
                buttons: [{
                        extend: 'pdf',
                        title: 'My Orders Report',
                        footer: true,
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                        },
                        footer: false
                    },
                    {
                        extend: 'print',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                        },
                        footer: true
                    }
                ],

            });

            $('#Admintable3').DataTable({
                dom: 'lBfrtip',
                bInfo: false,
                buttons: [{
                        extend: 'pdf',
                        title: 'My Orders Report',
                        footer: true,
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8]
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8]
                        },
                        footer: false
                    },
                    {
                        extend: 'print',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8]
                        },
                        footer: true
                    }
                ],

            });

            $('#Admintable4').DataTable({
                dom: 'lBfrtip',
                bInfo: false,
                buttons: [{
                        extend: 'pdf',
                        title: 'My Orders Report',
                        footer: true,
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8]
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8]
                        },
                        footer: false
                    },
                    {
                        extend: 'print',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8]
                        },
                        footer: true
                    }
                ],

            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NEDCO\resources\views/dispatcher/Order.blade.php ENDPATH**/ ?>