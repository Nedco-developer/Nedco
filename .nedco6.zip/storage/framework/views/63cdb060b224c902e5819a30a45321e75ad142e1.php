

<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>

    <br>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">Drivers</div>
            <div class="card-body">
                <?php if(\Session::has('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo \Session::get('error'); ?>

                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <table id="Admintable" class="table">
                        <thead>
                            <tr>
                                <th>
                                    Name
                                </th>
                                <th>
                                    Email
                                </th>
                                <th>
                                    Phone
                                </th>
                                <th>
                                    Age
                                </th>
                                <th>
                                    Address
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $Driver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($driver->name); ?></td>
                                    <td><?php echo e($driver->email); ?></td>
                                    <td><?php echo e($driver->phone); ?></td>
                                    <td><?php echo e($driver->age); ?></td>
                                    <td><?php echo e($driver->address); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
        <script>
            $(document).ready(function() {
                $('#Admintable').DataTable();
            });

        </script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NEDCO\resources\views/dispatcher/ViewAllDrivers.blade.php ENDPATH**/ ?>