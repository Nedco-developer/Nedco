<?php $__env->startSection('title', 'Add Districts Prices Form'); ?>

<?php $__env->startSection('content'); ?>

<br>
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"><?php echo e(__('Add Districts Prices Form')); ?></div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('submitDistrictsPrices')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo \Session::get('success'); ?>

                            </div>
                        <?php endif; ?>
                        <input type="hidden" class="form-control" name="user_id" value="<?php echo e($user_id); ?>" />
                        <!--<?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
                        <!-- <div class="form-group row">-->
                        <!--    <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e($district->name); ?></label>-->
                        <!--    <div class="col-md-6">-->
                        <!--        <input type="text" class="form-control" name="<?php echo e($district->id); ?>" value="" autofocus>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <!--<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
                <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <?php if(!count($userDistricts) > 0): ?>
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e($district->name); ?></label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="<?php echo e($district->id); ?>" value="" autofocus>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php $__currentLoopData = $userDistricts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Districts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($district->id != $Districts->district_id): ?>
                            <?php if($district->id == $Districts->district_id): ?>
                                <div class="form-group row">
                                    <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e($district->name); ?></label>
                                    <div class="col-md-6">
                                        <input type="text" class="form-control" name="<?php echo e($district->id); ?>" value="" autofocus>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if($district->id == $Districts->district_id): ?>
                           <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e($district->name); ?></label>
                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="<?php echo e($Districts->district_id); ?>" value="<?php echo e($Districts->price); ?>" autofocus>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-success">
                                    <?php echo e(__('Submit')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/mqjaujmy/NEDCO/resources/views/admin/districts_prices.blade.php ENDPATH**/ ?>