

<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>

    <style>
        .entity-menu>.nav-item>a.active {
            background-color: #000;
            border-bottom: 0px solid black !important;
        }

    </style>
    <ul class="entity-menu d-flex flex-row align-items-start entity-menu-small nav" role="tablist"
        style="margin-top: 1%;margin-left: 1%;margin-right: 1%;font-size: 21px;background-color: #ee293a;">
        <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#Today" style="color: #FFF;">Today Orders</a>
        </li>
        <li class="nav-item">
            <a class="nav-link " data-toggle="tab" href="#past" style="color: #FFF;">Past Orders</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#Next" style="color: #FFF;">Next Orders</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#all" style="color: #FFF;">All Orders</a>
        </li>

    </ul>
    <div style="margin-left: 1%;margin-right: 1%;" class="tab-content">
        <div id="Today" class="row justify-content-center tab-pane active">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <?php if(\Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo \Session::get('success'); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <div id="alert" style="display: none" class="alert alert-success"></div>
                        <table id="Admintable1">
                            <thead>
                                <tr>
                                    <th>
                                        Sender Name
                                    </th>
                                    <th>
                                        Sender Number
                                    </th>
                                    <th>
                                        Recipient Name
                                    </th>
                                    <th>
                                        Recipient Number
                                    </th>
                                    <th>
                                        Recipient Address
                                    </th>
                                    <th>
                                        City
                                    </th>
                                    <th>
                                        total Price
                                    </th>
                                    <th>
                                        Notes
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        Delivery Date
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $AssignOrdersToday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $assinedOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($assinedOrder->order->SenderName); ?></td>
                                        <td><?php echo e($assinedOrder->order->SenderNumber); ?></td>
                                        <td><?php echo e($assinedOrder->order->RecipientName); ?></td>
                                        <td><?php echo e($assinedOrder->order->RecipientNumber); ?></td>
                                        <td><?php echo e($assinedOrder->order->RecipientAddress); ?></td>
                                        <td><?php echo e($assinedOrder->order->city); ?></td>
                                        <td><?php echo e($assinedOrder->order->totalPrice); ?></td>
                                        <td><?php echo e($assinedOrder->order->notes); ?></td>
                                        <td>
                                            <input type="hidden" name="id" id="order_id" value="<?php echo e($assinedOrder->order->id); ?>"> 
                                            <select name="status" class="form-control" id="status">
                                                <option value="Delivered" <?php if($assinedOrder->order->status == 'Delivered'): ?> selected <?php endif; ?>>Delivered</option>
                                                <option value="No Answer" <?php if($assinedOrder->order->status == 'No Answer'): ?> selected <?php endif; ?>>No Answer</option>
                                                <option value="Turned  Answer" <?php if($assinedOrder->order->status == 'Turned Off'): ?> selected <?php endif; ?>>Turned Off</option>
                                                <option value="Disconnected" <?php if($assinedOrder->order->status == 'Disconnected'): ?> selected <?php endif; ?>>Disconnected</option>
                                                <option value="Out Of Reach" <?php if($assinedOrder->order->status == 'Out Of Reach'): ?> selected <?php endif; ?>>Out Of Reach</option>
                                                <option value="Cancelled" <?php if($assinedOrder->order->status == 'Cancelled'): ?> selected <?php endif; ?>>Cancelled</option>
                                                <option value="Rejected" <?php if($assinedOrder->order->status == 'Rejected'): ?> selected <?php endif; ?>>Rejected</option>
                                                <option value="Rejected With Charges" <?php if($assinedOrder->order->status == 'Rejected With Charges'): ?> selected <?php endif; ?>>Rejected With Charges</option>
                                            </select>
                                        </td>
                                        <td><?php echo e($assinedOrder->delivery_date); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div id="past" class="row justify-content-center tab-pane fade">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div id="alert" style="display: none" class="alert alert-success"></div>
                    <div class="card-body">
                        <table id="Admintable2">
                            <thead>
                                <tr>
                                    <th>
                                        Sender Name
                                    </th>
                                    <th>
                                        Sender Number
                                    </th>
                                    <th>
                                        Recipient Name
                                    </th>
                                    <th>
                                        Recipient Number
                                    </th>
                                    <th>
                                        Recipient Address
                                    </th>
                                    <th>
                                        City
                                    </th>
                                    <th>
                                        total Price
                                    </th>
                                    <th>
                                        Notes
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        Delivery Date
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $AssignOrdersLessToday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $assignorders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($assignorders->order->SenderName); ?></td>
                                        <td><?php echo e($assignorders->order->SenderNumber); ?></td>
                                        <td><?php echo e($assignorders->order->RecipientName); ?></td>
                                        <td><?php echo e($assignorders->order->RecipientNumber); ?></td>
                                        <td><?php echo e($assignorders->order->RecipientAddress); ?></td>
                                        <td><?php echo e($assignorders->order->city); ?></td>
                                        <td><?php echo e($assignorders->order->totalPrice); ?></td>
                                        <td><?php echo e($assignorders->order->notes); ?></td>
                                        <td><?php echo e($assignorders->order->status); ?></td>
                                        <td><?php echo e($assignorders->delivery_date); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div id="Next" class="row justify-content-center tab-pane fade">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table id="Admintable3">
                            <thead>
                                <tr>
                                    <th>
                                        Sender Name
                                    </th>
                                    <th>
                                        Sender Number
                                    </th>
                                    <th>
                                        Recipient Name
                                    </th>
                                    <th>
                                        Recipient Number
                                    </th>
                                    <th>
                                        Recipient Address
                                    </th>
                                    <th>
                                        City
                                    </th>
                                    <th>
                                        total Price
                                    </th>
                                    <th>
                                        Notes
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        Delivery Date
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $AssignOrdersLargerToday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $assignorders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($assignorders->order->SenderName); ?></td>
                                        <td><?php echo e($assignorders->order->SenderNumber); ?></td>
                                        <td><?php echo e($assignorders->order->RecipientName); ?></td>
                                        <td><?php echo e($assignorders->order->RecipientNumber); ?></td>
                                        <td><?php echo e($assignorders->order->RecipientAddress); ?></td>
                                        <td><?php echo e($assignorders->order->city); ?></td>
                                        <td><?php echo e($assignorders->order->totalPrice); ?></td>
                                        <td><?php echo e($assignorders->order->notes); ?></td>
                                        <td><?php echo e($assignorders->order->status); ?></td>
                                        <td><?php echo e($assignorders->delivery_date); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div id="all" class="row justify-content-center tab-pane fade">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table id="Admintable4">
                            <thead>
                                <tr>
                                    <th>
                                        Sender Name
                                    </th>
                                    <th>
                                        Sender Number
                                    </th>
                                    <th>
                                        Recipient Name
                                    </th>
                                    <th>
                                        Recipient Number
                                    </th>
                                    <th>
                                        Recipient Address
                                    </th>
                                    <th>
                                        City
                                    </th>
                                    <th>
                                        total Price
                                    </th>
                                    <th>
                                        Notes
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        Delivery Date
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $AssignOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $assignorders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($assignorders->order->SenderName); ?></td>
                                        <td><?php echo e($assignorders->order->SenderNumber); ?></td>
                                        <td><?php echo e($assignorders->order->RecipientName); ?></td>
                                        <td><?php echo e($assignorders->order->RecipientNumber); ?></td>
                                        <td><?php echo e($assignorders->order->RecipientAddress); ?></td>
                                        <td><?php echo e($assignorders->order->city); ?></td>
                                        <td><?php echo e($assignorders->order->totalPrice); ?></td>
                                        <td><?php echo e($assignorders->order->notes); ?></td>
                                        <td><?php echo e($assignorders->order->status); ?></td>
                                        <td><?php echo e($assignorders->delivery_date); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#Admintable1').DataTable({
                dom: 'lBfrtip',
                bInfo: false,
                buttons: [{
                        extend: 'pdf',
                        title: 'My Orders Report',
                        footer: true,
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                        },
                        footer: false
                    },
                    {
                        extend: 'print',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                        },
                        footer: true
                    }
                ],

            });

            $('#Admintable2').DataTable({
                dom: 'lBfrtip',
                bInfo: false,
                buttons: [{
                        extend: 'pdf',
                        title: 'My Orders Report',
                        footer: true,
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                        },
                        footer: false
                    },
                    {
                        extend: 'print',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                        },
                        footer: true
                    }
                ],

            });

            $('#Admintable3').DataTable({
                dom: 'lBfrtip',
                bInfo: false,
                buttons: [{
                        extend: 'pdf',
                        title: 'My Orders Report',
                        footer: true,
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8]
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8]
                        },
                        footer: false
                    },
                    {
                        extend: 'print',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8]
                        },
                        footer: true
                    }
                ],

            });

            $('#Admintable4').DataTable({
                dom: 'lBfrtip',
                bInfo: false,
                buttons: [{
                        extend: 'pdf',
                        title: 'My Orders Report',
                        footer: true,
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8]
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8]
                        },
                        footer: false
                    },
                    {
                        extend: 'print',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8]
                        },
                        footer: true
                    }
                ],

            });

            $('#status').on('change', function(event){
                event.preventDefault();
                let _token = '<?php echo e(csrf_token()); ?>';
                let id = $("#order_id").val();
                $.ajax({
                    url: "<?php echo e(route('cheangeStatus')); ?>",
                    type:"POST",
                    data:{
                        status: this.value, 
                        id: id,
                        _token: _token
                    },
                    success:function(response){
                        console.log(response);
                        $('#alert').css('display', 'block');
                        $('#alert').text(response)
                    },
                });
            });
            
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/mqjaujmy/NEDCO/resources/views/driver/driverOrder.blade.php ENDPATH**/ ?>