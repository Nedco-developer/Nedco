

<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>
<style>
.table-res{
        display: block !important;
        overflow-x: auto !important;
    }
        .entity-menu>.nav-item>a.active {
            background-color: #000;
            border-bottom: 0px solid black !important;
        }
        @media  only screen and (min-width: 320px) and (max-width: 568px) {
    .nav-link {
        margin-left: 1rem !important;
    }
    .side-container {
        height: 100% !important;
    }
    .side-container3 {
        height: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
        margin-left: 0rem !important;
    }
    .table-res{
        display: block !important;
        overflow-x: auto !important;
    }
}
@media  only screen and (max-width: 768px) and (max-width: 1024px) {
  .side-container {
         height: 100% !important;
    }
    .side-container3 {
        height: 100% !important;
    }
    .row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px !important;
    margin-left: 0px !important;
    }
    
    .text{
        font-size:1rem !important;
    }
    .home-form {
    width: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 1rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
    }
}
@media  only screen and (max-width: 600px) {
    .nav-link {
    margin-left: 1rem !important;
    }
  .side-container {
    height: 100% !important;
    }
    
    .side-container3 {
      height: 100% !important;
    }
    
    .row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px !important;
    margin-left: 0px !important;
    }
    
    .text{
        font-size:1rem !important;
    }
    .home-form {
    width: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 1rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
@media  only screen and (min-width: 601px) and (max-width: 768px) {
    .nav-link {
    margin-left: 1rem !important;
    }
    .side-container {
        height: 100% !important;
    }
    .side-container3 {
      height: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 0rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
@media  only screen and (max-width: 1024px) {
    .nav-link {
    margin-left: 1rem !important;
    }
    .text{
        font-size:0rem !important;
    }
    .home {
      padding: 94px 0px !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 0rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
    </style>

            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div class="card-header"><?php echo e(__('All Orders')); ?></div>
                    <div class="card-body">
                        <a class="btn btn-success" style="margin-bottom: 1rem;" href="/nedco/addOrder">Add New Order</a>
                        <a class="btn btn-success float-right" style="margin-bottom: 1rem;" href="/add-orders-from-excel">Add Orders From Exel</a>
                        <table id="Admintable1" class="display nowrap table-res table table-condensed " style="width:100%">
                            <thead>
                                <tr>
                                    <th>id</th>
                                    <th>Recipient Name</th>
                                    <th>Recipient Number</th>
                                    <th>City</th>
                                    <th>Recipient Address</th>
                                    <th>item Price</th>
                                    <th>delivery Price</th>
                                    <th>total Price</th>
                                    <th>Notes</th>
                                    <th>Status</th>
                                    <th>Assign Order</th>
                                    <th>View Details</th>
                                    <th>Edit</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Order->id); ?></td>
                                        <td><?php echo e($Order->RecipientName); ?></td>
                                        <td><?php echo e($Order->RecipientNumber); ?></td>
                                        <td><?php echo e($Order->city); ?></td>
                                        <td><?php echo e($Order->RecipientAddress); ?></td>
                                        <td><?php echo e($Order->itemPrice); ?></td>
                                        <td><?php echo e($Order->deliveryPrice); ?></td>
                                        <td><?php echo e($Order->totalPrice); ?></td>
                                        <td><?php echo e($Order->notes); ?></td>
                                        <td><?php echo e($Order->status); ?></td>
                                        <?php if($Order->status != 'Delivered'): ?>
                                        <td>
                                            <select style="width: 10rem;" required name="driver" id="driver_<?php echo e($Order->id); ?>" class="form-control">
                                                <?php $__currentLoopData = $Driver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Driver2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($Driver2->id); ?>" <?php if(isset($Order->assigned_order->Driver_id)): ?> <?php if($Order->assigned_order->Driver_id == $Driver2->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($Driver2->user->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
     
                                        <input type="date" name="delivery_date" min="<?php echo e(date('Y-m-d')); ?>" id="delivery_date_<?php echo e($Order->id); ?>" <?php if(isset($Order->assigned_order->delivery_date)): ?> value="<?php echo e($Order->assigned_order->delivery_date); ?>" <?php endif; ?>>
                                            <button id="<?php echo e($Order->id); ?>"
                                                class="submitAssgin btn btn-danger">Assign</button>
                                        </td>
                                        <?php else: ?>
                                        <td>Order has been deliverd</td>
                                        <?php endif; ?>
                                        <td>
                                            <a href="ViewDetailsOrder?id=<?php echo e($Order->id); ?>"
                                            class="btn btn-primary">View</a>
                                        </td>
                                        <td>
                                            <a href="editOrder?id=<?php echo e($Order->id); ?>"
                                            class="btn btn-primary">Edit</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>id</th>
                                    <th>Recipient Name</th>
                                    <th>Recipient Number</th>
                                    <th>City</th>
                                    <th>Recipient Address</th>
                                    <th>item Price</th>
                                    <th>delivery Price</th>
                                    <th>total Price</th>
                                    <th>Notes</th>
                                    <th>Status</th>
                            </tfoot>
                        </table>
                    </div>
                </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            
            $('.submitAssgin').on('click', function() {
                var order_id = $(this).attr('id');
                var driver_id = $('#driver_' + order_id).val();
                var delivery_date = $('#delivery_date_' + order_id).val();
                let _token = '<?php echo e(csrf_token()); ?>';
                $.ajax({
                    type: "post",
                    url: '<?php echo e(route("assign")); ?>',
                    data: {
                        _token: _token,
                        order_id: order_id,
                        driver_id: driver_id,
                        delivery_date: delivery_date
                    },
                    success: function(data) {
                        console.log(data);
                        location.reload();
                        $('#alert').css('display', 'block');
                        $('#alert').text(data)
                    }
                })
            });
            
            $('#Admintable1').DataTable({
                initComplete: function () {
                    count = 0;
                    this.api().columns().every( function () {
                        var title = this.header();
                        //replace spaces with dashes
                        title = $(title).html().replace(/[\W]/g, '-');
                        var column = this;
                        var select = $('<select id="' + title + '" class="select2" ></select>')
                            .appendTo( $(column.footer()).empty() )
                            .on( 'change', function () {
                              //Get the "text" property from each selected data 
                              //regex escape the value and store in array
                              var data = $.map( $(this).select2('data'), function( value, key ) {
                                return value.text ? '^' + $.fn.dataTable.util.escapeRegex(value.text) + '$' : null;
                                         });
                              
                              //if no data selected use ""
                              if (data.length === 0) {
                                data = [""];
                              }
                              
                              //join array into string with regex or (|)
                              var val = data.join('|');
                              
                              //search for the option(s) selected
                              column
                                    .search( val ? val : '', true, false )
                                    .draw();
                            } );
         
                        column.data().unique().sort().each( function ( d, j ) {
                            select.append( '<option value="'+d+'">'+d+'</option>' );
                        } );
                      
                      //use column title as selector and placeholder
                      $('#' + title).select2({
                        multiple: true,
                        closeOnSelect: false,
                        placeholder: title
                      });
                      
                      //initially clear select otherwise first option is selected
                      $('.select2').val(null).trigger('change');
                    } );
                },
                dom: 'lBfrtip',
                bInfo: false,
                order: [ 0, 'desc' ],
                buttons: [{
                        extend: 'pdf',
                        title: 'My Orders Report',
                        footer: true,
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        },
                        footer: false
                    },
                    {
                        extend: 'print',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        },
                        footer: true
                    }
                ],

            });

            $('#Admintable2').DataTable({
                initComplete: function () {
                    count = 0;
                    this.api().columns().every( function () {
                        var title = this.header();
                        //replace spaces with dashes
                        title = $(title).html().replace(/[\W]/g, '-');
                        var column = this;
                        var select = $('<select id="' + title + '" class="select2" ></select>')
                            .appendTo( $(column.footer()).empty() )
                            .on( 'change', function () {
                              //Get the "text" property from each selected data 
                              //regex escape the value and store in array
                              var data = $.map( $(this).select2('data'), function( value, key ) {
                                return value.text ? '^' + $.fn.dataTable.util.escapeRegex(value.text) + '$' : null;
                                         });
                              
                              //if no data selected use ""
                              if (data.length === 0) {
                                data = [""];
                              }
                              
                              //join array into string with regex or (|)
                              var val = data.join('|');
                              
                              //search for the option(s) selected
                              column
                                    .search( val ? val : '', true, false )
                                    .draw();
                            } );
         
                        column.data().unique().sort().each( function ( d, j ) {
                            select.append( '<option value="'+d+'">'+d+'</option>' );
                        } );
                      
                      //use column title as selector and placeholder
                      $('#' + title).select2({
                        multiple: true,
                        closeOnSelect: false,
                        placeholder: title
                      });
                      
                      //initially clear select otherwise first option is selected
                      $('.select2').val(null).trigger('change');
                    } );
                },
                dom: 'lBfrtip',
                bInfo: false,
                order: [[ 0, "desc" ]],
                buttons: [{
                        extend: 'pdf',
                        title: 'My Orders Report',
                        footer: true,
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        },
                        footer: false
                    },
                    {
                        extend: 'print',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        },
                        footer: true
                    }
                ],

            });

            $('#Admintable3').DataTable({
                initComplete: function () {
                    count = 0;
                    this.api().columns().every( function () {
                        var title = this.header();
                        //replace spaces with dashes
                        title = $(title).html().replace(/[\W]/g, '-');
                        var column = this;
                        var select = $('<select id="' + title + '" class="select2" ></select>')
                            .appendTo( $(column.footer()).empty() )
                            .on( 'change', function () {
                              //Get the "text" property from each selected data 
                              //regex escape the value and store in array
                              var data = $.map( $(this).select2('data'), function( value, key ) {
                                return value.text ? '^' + $.fn.dataTable.util.escapeRegex(value.text) + '$' : null;
                                         });
                              
                              //if no data selected use ""
                              if (data.length === 0) {
                                data = [""];
                              }
                              
                              //join array into string with regex or (|)
                              var val = data.join('|');
                              
                              //search for the option(s) selected
                              column
                                    .search( val ? val : '', true, false )
                                    .draw();
                            } );
         
                        column.data().unique().sort().each( function ( d, j ) {
                            select.append( '<option value="'+d+'">'+d+'</option>' );
                        } );
                      
                      //use column title as selector and placeholder
                      $('#' + title).select2({
                        multiple: true,
                        closeOnSelect: false,
                        placeholder: title
                      });
                      
                      //initially clear select otherwise first option is selected
                      $('.select2').val(null).trigger('change');
                    } );
                },
                dom: 'lBfrtip',
                bInfo: false,
                order: [ 0, 'desc' ],
                buttons: [{
                        extend: 'pdf',
                        title: 'My Orders Report',
                        footer: true,
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        },
                        footer: false
                    },
                    {
                        extend: 'print',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        },
                        footer: true
                    }
                ],

            });

            $('#Admintable4').DataTable({
                initComplete: function () {
                    count = 0;
                    this.api().columns().every( function () {
                        var title = this.header();
                        //replace spaces with dashes
                        title = $(title).html().replace(/[\W]/g, '-');
                        var column = this;
                        var select = $('<select id="' + title + '" class="select2" ></select>')
                            .appendTo( $(column.footer()).empty() )
                            .on( 'change', function () {
                              //Get the "text" property from each selected data 
                              //regex escape the value and store in array
                              var data = $.map( $(this).select2('data'), function( value, key ) {
                                return value.text ? '^' + $.fn.dataTable.util.escapeRegex(value.text) + '$' : null;
                                         });
                              
                              //if no data selected use ""
                              if (data.length === 0) {
                                data = [""];
                              }
                              
                              //join array into string with regex or (|)
                              var val = data.join('|');
                              
                              //search for the option(s) selected
                              column
                                    .search( val ? val : '', true, false )
                                    .draw();
                            } );
         
                        column.data().unique().sort().each( function ( d, j ) {
                            select.append( '<option value="'+d+'">'+d+'</option>' );
                        } );
                      
                      //use column title as selector and placeholder
                      $('#' + title).select2({
                        multiple: true,
                        closeOnSelect: false,
                        placeholder: title
                      });
                      
                      //initially clear select otherwise first option is selected
                      $('.select2').val(null).trigger('change');
                    } );
                },
                dom: 'lBfrtip',
                bInfo: false,
                order: [ 0, 'desc' ],
                buttons: [{
                        extend: 'pdf',
                        title: 'My Orders Report',
                        footer: true,
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        },
                        footer: false
                    },
                    {
                        extend: 'print',
                        title: 'My Orders Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                        },
                        footer: true
                    }
                ],

            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\O Minus\Desktop\NedcoLaravel\resources\views/admin/viewAllOrders.blade.php ENDPATH**/ ?>