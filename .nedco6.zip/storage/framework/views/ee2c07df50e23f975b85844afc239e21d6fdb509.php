

<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Add Locations')); ?></div>

                <div class="card-body">
                    <form method="POST" action="/SubmitLocation" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo \Session::get('success'); ?>

                            </div>
                        <?php endif; ?>
                        <div class="form-group row">
                            <label for="type" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Client')); ?></label>
                            <div class="col-md-6">
                                <select required name="Client" id="Client" class="form-control">
                                    <option disabled>select Client</option>
                                    <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($Client->name); ?>"><?php echo e($Client->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="type" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Region')); ?></label>
                            <div class="col-md-6">
                                <select required name="Region" id="Region" class="form-control">
                                    <option disabled>select Region</option>
                                    <option value="Amman-عمان">Amman-عمان</option>
                                        <option value="Irbid-اربد">Irbid-اربد</option>
                                        <option value="Ajloun-عجلون">Ajloun-عجلون</option>
                                        <option value="Jerash-جرش">Jerash-جرش</option>
                                        <option value="Salt-السلط">Salt-السلط</option>
                                        <option value="Zarqa-الزرقاء">Zarqa-الزرقاء</option>
                                        <option value="Madaba-مادبا">Madaba-مادبا</option>
                                        <option value="AlKarak-الكرك">Al Karak-الكرك</option>
                                        <option value="Tafilah-الطفيله">Tafilah-الطفيله</option>
                                        <option value="Ma'an-معان">Ma'an-معان</option>
                                        <option value="Aqaba-العقبه">Aqaba-العقبه</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="type" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Site')); ?></label>
                            <div class="col-md-6">
                                <select required name="Site" id="Site" class="form-control">
                                    <option disabled>select Site</option>
                                    <option value="North-الشمال">North-الشمال</option>
                                    <option value="South-الجنوب">South-الجنوب</option>
                                    <option value="Middle-الوسط">Middle-الوسط</option>
                                    <option value="Amman-عمان">Amman-عمان</option>
                                    <option value="depressions-الاغوار">depressions-الاغوار</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Delivary Price')); ?></label>

                            <div class="col-md-6">
                                <input id="Price" type="text" class="form-control" name="Price" value="<?php echo e(old('Price')); ?>" required autofocus>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-success">
                                    <?php echo e(__('Save')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NEDCO\resources\views/admin/Locations.blade.php ENDPATH**/ ?>