

<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>

<br>
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"><?php echo e(__('New Order Form')); ?></div>

                <div class="card-body">
                    <form method="POST" action="/submitOrdes?id=<?php echo e(Auth::user()->id); ?>">
                        <?php echo csrf_field(); ?>
                        <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo \Session::get('success'); ?>

                            </div>
                        <?php endif; ?>
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Sender number')); ?></label>

                            <div class="col-md-6">
                            <input id="Sendernumber" type="text" class="form-control" name="Sendernumber" value="<?php echo e($client->phone); ?>" required autofocus>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Sender name')); ?></label>

                            <div class="col-md-6">
                                <input id="Sendername" type="text" class="form-control" name="Sendername" value="<?php echo e($User->name); ?>" required autofocus>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Recipient number')); ?></label>

                            <div class="col-md-6">
                                <input id="Recipientnumber" type="text" class="form-control" name="Recipientnumber" value="" required autofocus>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Recipient name')); ?></label>

                            <div class="col-md-6">
                                <input id="Recipientname" type="text" class="form-control" name="Recipientname" value="" required autofocus>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="type" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Recipient City')); ?></label>
                            <div class="col-md-6">
                                <select required name="city" id="city" class="form-control">
                                        <option value="Amman">Amman-عمان</option>
                                        <option value="Irbid">Irbid-اربد</option>
                                        <option value="Ajloun">Ajloun-عجلون</option>
                                        <option value="Jerash">Jerash-جرش</option>
                                        <option value="Salt">Salt-السلط</option>
                                        <option value="Zarqa">Zarqa-الزرقاء</option>
                                        <option value="Madaba">Madaba-مادبا</option>
                                        <option value="AlKarak">Al Karak-الكرك</option>
                                        <option value="Tafilah">Tafilah-الطفيله</option>
                                        <option value="Ma'an">Ma'an-معان</option>
                                        <option value="Aqaba">Aqaba-العقبه</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Recipient Address')); ?></label>

                            <div class="col-md-6">
                                <textarea id="Recipientaddress" type="text" class="form-control" name="Recipientaddress" value="" required autofocus>
                                </textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Item Price')); ?></label>

                            <div class="col-md-6">
                                <input id="itemprice" type="text" class="form-control price" name="itemprice" value="" required autofocus>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Delivery Price')); ?></label>

                            <div class="col-md-6">
                                <input id="deliveryprice" type="text" class="form-control price" name="deliveryprice" value="" required autofocus>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Total Price')); ?></label>

                            <div class="col-md-6">
                                <input id="totalprice" disabled type="text" class="form-control" value="" required>
                                <input id="totalprice2"  type="hidden" class="form-control" name="totalprice" value="" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Notes')); ?></label>

                            <div class="col-md-6">
                                <textarea id="notes" type="text" class="form-control" name="notes" value="" required autofocus>
                                </textarea>
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-success">
                                    <?php echo e(__('Submit')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    // we used jQuery 'keyup' to trigger the computation as the user type
    $('.price').keyup(function () {
     
        // initialize the sum (total price) to zero
        var sum = 0;
         
        // we use jQuery each() to loop through all the textbox with 'price' class
        // and compute the sum for each loop
        $('.price').each(function() {
            sum += Number($(this).val());
        });
         
        // set the computed value to 'totalPrice' textbox
        $('#totalprice').attr('value', sum);
        $('#totalprice2').attr('value', sum);
         
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NEDCO\resources\views/client/Order.blade.php ENDPATH**/ ?>