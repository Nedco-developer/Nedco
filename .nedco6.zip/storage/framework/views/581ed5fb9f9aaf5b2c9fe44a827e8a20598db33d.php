<?php $__env->startSection('content'); ?>
<style>

</style>
<body>
    <section id='home2'>
        <div class="row container-fluid">
            <div class="col-md-4">
                <img src="images/logo-background.png" class="" alt="logo-background">
            </div>
            <div class="col-md-1">
                <img style="height:10rem" src="images/Line-background.png" class="" alt="Line-background">
            </div>
            <div class="col-md-5">
                <div class="col-md-1">
                    <a>test</a>
                </div>
                <div class="col-md-1">
                    <a>test</a>
                </div>
                <div class="col-md-1">
                    <a>test</a>
                </div>
                <div class="col-md-1">
                    <a>test</a>
                </div>
                <div class="col-md-1">
                    <a>test</a>
                </div>
                <div class="col-md-1">
                    <a>test</a>
                </div>
            </div>
            <div class="col-md-2">
                <a href="#"><img src="images/in-background.png" class="" alt="in-background"></a>
                <a href="#"><img src="images/f-background.png" class="" alt="f-background"></a>
            </div>
        </div>
    </section>
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/mqjaujmy/NEDCO/resources/views/layouts/footer.blade.php ENDPATH**/ ?>