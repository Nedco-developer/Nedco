

<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .table-res{
        display: block !important;
        overflow-x: auto !important;
    }
    .entity-menu>.nav-item>a.active {
            background-color: #000;
            border-bottom: 0px solid black !important;
        }
    @media  only screen and (min-width: 320px) and (max-width: 568px) {
    .nav-link {
        margin-left: 1rem !important;
    }
    .side-container {
        height: 100% !important;
    }
    .side-container3 {
        height: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
        margin-left: 0rem !important;
    }
    .table-res{
        display: block !important;
        overflow-x: auto !important;
    }
}
    @media  only screen and (max-width: 768px) and (max-width: 1024px) {
  .side-container {
         height: 100% !important;
    }
    .side-container3 {
        height: 100% !important;
    }
    .row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px !important;
    margin-left: 0px !important;
    }
    
    .text{
        font-size:1rem !important;
    }
    .home-form {
    width: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 1rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
    }
}
    @media  only screen and (max-width: 600px) {
    .nav-link {
    margin-left: 1rem !important;
    }
  .side-container {
    height: 100% !important;
    }
    
    .side-container3 {
      height: 100% !important;
    }
    
    .row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px !important;
    margin-left: 0px !important;
    }
    
    .text{
        font-size:1rem !important;
    }
    .home-form {
    width: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 1rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
    @media  only screen and (min-width: 601px) and (max-width: 768px) {
    .nav-link {
    margin-left: 1rem !important;
    }
    .side-container {
        height: 100% !important;
    }
    .side-container3 {
      height: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 0rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
    @media  only screen and (max-width: 1024px) {
    .nav-link {
    margin-left: 1rem !important;
    }
    .text{
        font-size:0rem !important;
    }
    .home {
      padding: 94px 0px !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 0rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
</style>
    
    <ul class="entity-menu d-flex flex-row align-items-start entity-menu-small nav" role="tablist"
        style="margin-top: 1%;margin-left: 1%;margin-right: 1%;font-size: 21px;background-color: #ee293a;">
        <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#Yearly" style="color: #FFF;">All</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#Dailly" style="color: #FFF;">To Day</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#Weekly" style="color: #FFF;">Weekly</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#Monthly" style="color: #FFF;">Monthly</a>
        </li>
    </ul>
    
    <div style="margin-left: 1%;margin-right: 1%;" class="tab-content">
        
        <div id="Yearly" class="row justify-content-center tab-pane active">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table id="Admintable4" class="display nowrap table-res table table-condensed">
                            <thead>
                                <tr>
                                    <th>Y_id</th>
                                    <th>Y_status</th>
                                    <th>Y_payment status</th>
                                    <th>Y_city</th>
                                    <th>Y_item Price</th>
                                    <th>Y_delivery Price</th>
                                    <th>Y_total Price</th>
                                    <th>Y_notes</th>
                                </tr>
                            </thead>
                            <tbody id="yearlyBody">
                                <?php $__currentLoopData = $OrdersY; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ordersY): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($ordersY->id); ?></td>
                                        <td><?php echo e($ordersY->status); ?></td>
                                        <td><?php echo e($ordersY->payment_status); ?></td>
                                        <td><?php echo e($ordersY->city); ?></td>
                                        <td><?php echo e($ordersY->itemPrice); ?></td>
                                        <td><?php echo e($ordersY->deliveryPrice); ?></td>
                                        <td><?php echo e($ordersY->totalPrice); ?></td>
                                        <td><?php echo e($ordersY->notes); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </tbody>
                            <tfoot id="yearlyFooter">
                                <tr>
                                    <th>Y_id</th>
                                    <th>Y_status</th>
                                    <th>Y_payment status</th>
                                    <th>Y_city</th>
                                    <th>Y_item Price</th>
                                    <th>Y_delivery Price</th>
                                    <th>Y_total Price</th>
                                    
                                    <th>Y_notes</th>
                                </tr>
                                <tr class="yearlyFilter">
                                    <td>yearly Item : <?php echo e($yearlyItem); ?></td>
                                    <td>yearly Delivery : <?php echo e($yearlyDelivery); ?></td>
                                    <td>yearly Total : <?php echo e($yearlyTotal); ?></td>
                                    <td>Total yearly Driver : <?php echo e($TotalyearlyDriver); ?></td>
                                    <td>total yearly Net : <?php echo e($totalyearlyNet); ?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr class="yearlyFilter">
                                    <th></th>
                                    <th>From : <input type="date" onchange="changeto()" id="From" name="From"></th>
                                    <th></th>
                                    <th>To : <input type="date" id="To" name="To"></th>
                                    <th><a type="submit" id="Search" onclick="myFunction()" class="btn btn-success">Search</a></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="Dailly" class="row justify-content-center tab-pane fade">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table id="Admintable1" class="display nowrap table-res table table-condensed " >
                            <thead>
                                <tr>
                                    <th>id</th>
                                    <th>status</th>
                                    <th>payment status</th>
                                    <th>city</th>
                                    <th>item Price</th>
                                    <th>delivery Price</th>
                                    <th>total Price</th>
                                    
                                    <th>notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $OrdersD; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ordersD): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($ordersD->id); ?></td>
                                        <td><?php echo e($ordersD->status); ?></td>
                                        <td><?php echo e($ordersD->payment_status); ?></td>
                                        <td><?php echo e($ordersD->city); ?></td>
                                        <td><?php echo e($ordersD->itemPrice); ?></td>
                                        <td><?php echo e($ordersD->deliveryPrice); ?></td>
                                        <td><?php echo e($ordersD->totalPrice); ?></td>
                                        
                                        <td><?php echo e($ordersD->notes); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>id</th>
                                    <th>status</th>
                                    <th>payment status</th>
                                    <th>city</th>
                                    <th>item Price</th>
                                    <th>delivery Price</th>
                                    <th>total Price</th>
                                    
                                    <th>notes</th>
                                </tr>
                                <tr>
                                    <td>Dailly Item : <?php echo e($DaillyItem); ?></td>
                                    <td>Dailly Delivery : <?php echo e($DaillyDelivery); ?></td>
                                    <td>Dailly Total : <?php echo e($DaillyTotal); ?></td>
                                    <td>Total Dailly Driver : <?php echo e($TotalDaillyDriver); ?></td>
                                    <td>total Dailly Net : <?php echo e($totalDaillyNet); ?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="Weekly" class="row justify-content-center tab-pane fade">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table id="Admintable2" class="display nowrap table-res table table-condensed ">
                            <thead>
                                <tr>
                                    <th>W_id</th>
                                    <th>W_status</th>
                                    <th>W_payment status</th>
                                    <th>W_city</th>
                                    <th>W_item Price</th>
                                    <th>W_delivery Price</th>
                                    <th>W_total Price</th>
                                    
                                    <th>W_notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $OrdersW; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ordersW): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($ordersW->id); ?></td>
                                        <td><?php echo e($ordersW->status); ?></td>
                                        <td><?php echo e($ordersW->payment_status); ?></td>
                                        <td><?php echo e($ordersW->city); ?></td>
                                        <td><?php echo e($ordersW->itemPrice); ?></td>
                                        <td><?php echo e($ordersW->deliveryPrice); ?></td>
                                        <td><?php echo e($ordersW->totalPrice); ?></td>
                                        
                                        <td><?php echo e($ordersW->notes); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>W_id</th>
                                    <th>W_status</th>
                                    <th>W_payment status</th>
                                    <th>W_city</th>
                                    <th>W_item Price</th>
                                    <th>W_delivery Price</th>
                                    <th>W_total Price</th>
                                    
                                    <th>W_notes</th>
                                </tr>
                                <tr>
                                    <td>Weekly Item : <?php echo e($WeeklyItem); ?></td>
                                    <td>Weekly Delivery : <?php echo e($WeeklyDelivery); ?></td>
                                    <td>Weekly Total : <?php echo e($WeeklyTotal); ?></td>
                                    <td>Total Weekly Driver : <?php echo e($TotalWeeklyDriver); ?></td>
                                    <td>total Weekly Net : <?php echo e($totalWeeklyNet); ?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="Monthly" class="row justify-content-center tab-pane fade">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table id="Admintable3" class="display nowrap table-res table table-condensed " >
                            <thead>
                                <tr>
                                    <th>M_id</th>
                                    <th>M_status</th>
                                    <th>M_payment status</th>
                                    <th>M_city</th>
                                    <th>M_item Price</th>
                                    <th>M_delivery Price</th>
                                    <th>M_total Price</th>
                                    
                                    <th>M_notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $OrdersM; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ordersM): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($ordersM->id); ?></td>
                                        <td><?php echo e($ordersM->status); ?></td>
                                        <td><?php echo e($ordersM->payment_status); ?></td>
                                        <td><?php echo e($ordersM->city); ?></td>
                                        <td><?php echo e($ordersM->itemPrice); ?></td>
                                        <td><?php echo e($ordersM->deliveryPrice); ?></td>
                                        <td><?php echo e($ordersM->totalPrice); ?></td>
                                        
                                        <td><?php echo e($ordersM->notes); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>M_id</th>
                                    <th>M_status</th>
                                    <th>M_payment status</th>
                                    <th>M_city</th>
                                    <th>M_item Price</th>
                                    <th>M_delivery Price</th>
                                    <th>M_total Price</th>
                                    
                                    <th>M_notes</th>
                                </tr>
                                <tr>
                                    <td>monthly Item : <?php echo e($monthlyItem); ?></td>
                                    <td>monthly Delivery : <?php echo e($monthlyDelivery); ?></td>
                                    <td>monthly Total : <?php echo e($monthlyTotal); ?></td>
                                    <td>Total monthly Driver : <?php echo e($TotalmonthlyDriver); ?></td>
                                    <td>total monthly Net : <?php echo e($totalmonthlyNet); ?></td>
                                    <td></td>
                                    <td></td>
                                    <th></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>

<script type="text/javascript">
    function changeto(){
        let FromDate = document.getElementById("From").value;
        $('#To').attr("min", FromDate);
    }
    
    function myFunction(){
        let FromDate = document.getElementById("From").value;
        let ToDate = document.getElementById("To").value;
        $.ajax({
            url:"<?php echo e(route('Search')); ?>",
            type:'GET',
            data:{FromDate: FromDate, ToDate: ToDate},
            success:function(data){
                $('#yearlyBody').remove();
                $('#Admintable4').append('<tbody id="yearlyBody"></tbody>');
                $.each(data.yearlyOrder, function(index, value) {
                    $('#yearlyBody').append('<tr><td>'+ value.id +' </td><td>'+ value.payment_status +' </td><td>'+ value.city +' </td><td>'+ value.itemPrice +' </td><td>'+ value.deliveryPrice +' </td><td>'+ value.totalPrice +' </td><td>'+ value.status +' </td><td>'+ value.notes +' </td></tr>'); 
                });                    
                $('.yearlyFilter').remove();
                
                $('#yearlyFooter').append('<tr class="yearlyFilter"><td>yearly Item : '+  data.yearlyItem +'</td><td>yearly Delivery : '+ data.yearlyDelivery +'</td><td>yearly Total : '+ data.yearlyTotal +'</td><td>Total yearly Driver : '+ data.TotalyearlyDriver +'</td><td>total yearly Net : '+ data.totalyearlyNet +'</td><td></td><td></td><td></td></tr>');
           
                $('#yearlyFooter').append('<tr class="yearlyFilter"><th></th><th>From : <input type="date" onchange="changeto()" id="From" name="From"></th><th></th><th>To : <input type="date" id="To" name="To"></th><th><a type="submit" id="Search" onclick="myFunction()" class="btn btn-success">Search</a></th><th></th><td></td></td><td></tr>');
                
            }                        
        });
    }
    
    $(document).ready(function() {

        $('#Admintable1').DataTable({
              initComplete: function () {
                count = 0;
                this.api().columns().every( function () {
                    var title = this.header();
                    //replace spaces with dashes
                    title = $(title).html().replace(/[\W]/g, '-');
                    var column = this;
                    var select = $('<select style="width: 100% !important" id="' + title + '" class="select2" ></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                          //Get the "text" property from each selected data 
                          //regex escape the value and store in array
                          var data = $.map( $(this).select2('data'), function( value, key ) {
                            return value.text ? '^' + $.fn.dataTable.util.escapeRegex(value.text) + '$' : null;
                                     });
                          
                          //if no data selected use ""
                          if (data.length === 0) {
                            data = [""];
                          }
                          
                          //join array into string with regex or (|)
                          var val = data.join('|');
                          
                          //search for the option(s) selected
                          column
                                .search( val ? val : '', true, false )
                                .draw();
                        } );
     
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' );
                    } );
                  
                  //use column title as selector and placeholder
                  $('#' + title).select2({
                    multiple: true,
                    closeOnSelect: false,
                    placeholder: title
                  });
                  
                  //initially clear select otherwise first option is selected
                  $('.select2').val(null).trigger('change');
                } );
            },
            dom: 'lBfrtip',
            bInfo: false,
            buttons: [{
                    extend: 'pdf',
                    title: 'My Orders Report',
                    footer: true,
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    }
                },
                {
                    extend: 'excel',
                    title: 'My Orders Report',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    },
                    footer: false
                },
                {
                    extend: 'print',
                    title: 'My Orders Report',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    },
                    footer: true
                }
            ],

        });

        $('#Admintable2').DataTable({
            initComplete: function () {
                count = 0;
                this.api().columns().every( function () {
                    var title = this.header();
                    //replace spaces with dashes
                    title = $(title).html().replace(/[\W]/g, '-');
                    var column = this;
                    var select = $('<select style="width: 100% !important" id="' + title + '" class="select2" ></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                          //Get the "text" property from each selected data 
                          //regex escape the value and store in array
                          var data = $.map( $(this).select2('data'), function( value, key ) {
                            return value.text ? '^' + $.fn.dataTable.util.escapeRegex(value.text) + '$' : null;
                                     });
                          
                          //if no data selected use ""
                          if (data.length === 0) {
                            data = [""];
                          }
                          
                          //join array into string with regex or (|)
                          var val = data.join('|');
                          
                          //search for the option(s) selected
                          column
                                .search( val ? val : '', true, false )
                                .draw();
                        } );
     
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' );
                    } );
                  
                  //use column title as selector and placeholder
                  $('#' + title).select2({
                    multiple: true,
                    closeOnSelect: false,
                    placeholder: title
                  });
                  
                  //initially clear select otherwise first option is selected
                  $('.select2').val(null).trigger('change');
                } );
            },
            dom: 'lBfrtip',
            bInfo: false,
            buttons: [{
                    extend: 'pdf',
                    title: 'My Orders Report',
                    footer: true,
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    }
                },
                {
                    extend: 'excel',
                    title: 'My Orders Report',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    },
                    footer: false
                },
                {
                    extend: 'print',
                    title: 'My Orders Report',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    },
                    footer: true
                }
            ],

        });

        $('#Admintable3').DataTable({
            initComplete: function () {
                count = 0;
                this.api().columns().every( function () {
                    var title = this.header();
                    //replace spaces with dashes
                    title = $(title).html().replace(/[\W]/g, '-');
                    var column = this;
                    var select = $('<select style="width: 100% !important" id="' + title + '" class="select2" ></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                          //Get the "text" property from each selected data 
                          //regex escape the value and store in array
                          var data = $.map( $(this).select2('data'), function( value, key ) {
                            return value.text ? '^' + $.fn.dataTable.util.escapeRegex(value.text) + '$' : null;
                                     });
                          
                          //if no data selected use ""
                          if (data.length === 0) {
                            data = [""];
                          }
                          
                          //join array into string with regex or (|)
                          var val = data.join('|');
                          
                          //search for the option(s) selected
                          column
                                .search( val ? val : '', true, false )
                                .draw();
                        } );
     
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' );
                    } );
                  
                  //use column title as selector and placeholder
                  $('#' + title).select2({
                    multiple: true,
                    closeOnSelect: false,
                    placeholder: title
                  });
                  
                  //initially clear select otherwise first option is selected
                  $('.select2').val(null).trigger('change');
                } );
            },
            dom: 'lBfrtip',
            bInfo: false,
            buttons: [{
                    extend: 'pdf',
                    title: 'My Orders Report',
                    footer: true,
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    }
                },
                {
                    extend: 'excel',
                    title: 'My Orders Report',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    },
                    footer: false
                },
                {
                    extend: 'print',
                    title: 'My Orders Report',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    },
                    footer: true
                }
            ],

        });

        $('#Admintable4').DataTable({
            initComplete: function () {
                count = 0;
                this.api().columns().every( function () {
                    var title = this.header();
                    //replace spaces with dashes
                    title = $(title).html().replace(/[\W]/g, '-');
                    var column = this;
                    var select = $('<select style="width: 100% !important" id="' + title + '" class="select2" ></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                          //Get the "text" property from each selected data 
                          //regex escape the value and store in array
                          var data = $.map( $(this).select2('data'), function( value, key ) {
                            return value.text ? '^' + $.fn.dataTable.util.escapeRegex(value.text) + '$' : null;
                                     });
                          
                          //if no data selected use ""
                          if (data.length === 0) {
                            data = [""];
                          }
                          
                          //join array into string with regex or (|)
                          var val = data.join('|');
                          
                          //search for the option(s) selected
                          column
                                .search( val ? val : '', true, false )
                                .draw();
                        } );
     
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' );
                    } );
                  
                  //use column title as selector and placeholder
                  $('#' + title).select2({
                    multiple: true,
                    closeOnSelect: false,
                    placeholder: title
                  });
                  
                  //initially clear select otherwise first option is selected
                  $('.select2').val(null).trigger('change');
                } );
            },
            dom: 'lBfrtip',
            bInfo: false,
            buttons: [{
                    extend: 'pdf',
                    title: 'My Orders Report',
                    footer: true,
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    }
                },
                {
                    extend: 'excel',
                    title: 'My Orders Report',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    },
                    footer: false
                },
                {
                    extend: 'print',
                    title: 'My Orders Report',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,9]
                    },
                    footer: true
                }
            ],

        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/mqjaujmy/NEDCO/resources/views/Reports/Admin_Reports.blade.php ENDPATH**/ ?>