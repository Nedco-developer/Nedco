
<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>
<br>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><?php echo e(__('Locations prices')); ?></div>

            <div class="card-body">
                <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php if(\Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo \Session::get('success'); ?>

                        </div>
                    <?php endif; ?>
                <div class="form-group row md-2">
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group col md-2">
                        <button class="btn btn-primary"><a href="districts-prices?id=<?php echo e($city->id); ?>&user_id=<?php echo e($user_id); ?>"><?php echo e($city->name); ?></a></button>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                    <div class="form-group row mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Continue')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/mqjaujmy/NEDCO/resources/views/admin/cities_prices.blade.php ENDPATH**/ ?>