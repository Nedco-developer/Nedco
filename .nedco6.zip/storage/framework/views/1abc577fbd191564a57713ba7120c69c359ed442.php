<?php $__env->startSection('content'); ?>
<div class="container-fliud">
    <div class="row">
        <div class="index col-md-3">
             <div class="side-container3 color">
                 <img src="images/Group 12.png" alt="map">
                <div class="side-container2 color">
                     <img src="images/Track Shipments.png" alt="map">
                </div>
             </div>
         </div>
         <div class="col-md-6">
             <div class="track-form" style="margin-bottom: 1rem;">
                 <div class="card">
                     <!--<div class="card-header color">Tracking Result</div>-->
                    <div style="width: 101.5%;" class="card-body"/>
                         <br>
                         <h5>Tracking Result</h5>
                         <br>
                         <table class="table table-condensed " style="width:100%">
                         <thead style="background: #f5f6f8;">
                                <tr>
                                    <th>data id</th>
                                    <th></th>
                                    <th>data id</th>
                                    <th></th>
                                    <th>data id</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th>data 1</th>
                                    <th></th>
                                    <th>data 2</th>
                                    <th></th>
                                    <th>data 3</th>
                                </tr>
                                <tr>
                                    <th>data 4</th>
                                    <th></th>
                                    <th>data 5</th>
                                    <th></th>
                                    <th>data 6</th>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/mqjaujmy/NEDCO/resources/views/Check-Shapping-Rate.blade.php ENDPATH**/ ?>