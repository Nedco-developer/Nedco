

<?php $__env->startSection('title', 'Drivers'); ?>

<?php $__env->startSection('content'); ?>

    <div style="margin-left: 1%;margin-right: 1%;" class="tab-content">
        <div id="Drivrs" class="row justify-content-center tab-pane active">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Drivers</div>
                    <div class="card-body">
                        <?php if(\Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo \Session::get('error'); ?>

                            </div>
                        <?php endif; ?>
                        <table id="Admintable1">
                            <thead>
                                <tr>
                                    <th>
                                        Name
                                    </th>
                                    <th>
                                        Email
                                    </th>
                                    <th>
                                        Phone
                                    </th>
                                    <th>
                                        Age
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Driver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Drivers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Drivers->user->name); ?></td>
                                        <td><?php echo e($Drivers->user->email); ?></td>
                                        <td><?php echo e($Drivers->user->phone); ?></td>
                                        <td><?php echo e($Drivers->age); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#Admintable1').DataTable();
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/mqjaujmy/NEDCO/resources/views/monitor/drivers.blade.php ENDPATH**/ ?>