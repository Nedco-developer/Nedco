

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <style>
        .entity-menu>.nav-item>a.active {
            background-color: #000;
            border-bottom: 0px solid black !important;
        }
        @media  only screen and (min-width: 320px) and (max-width: 568px) {
    .nav-link {
        margin-left: 1rem !important;
    }
    .side-container {
        height: 100% !important;
    }
    .side-container3 {
        height: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
        margin-left: 0rem !important;
    }
    .table-res{
        display: block !important;
        overflow-x: auto !important;
    }
}
@media  only screen and (max-width: 768px) and (max-width: 1024px) {
  .side-container {
         height: 100% !important;
    }
    .side-container3 {
        height: 100% !important;
    }
    .row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px !important;
    margin-left: 0px !important;
    }
    
    .text{
        font-size:1rem !important;
    }
    .home-form {
    width: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 1rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
    }
}
@media  only screen and (max-width: 600px) {
    .nav-link {
    margin-left: 1rem !important;
    }
  .side-container {
    height: 100% !important;
    }
    
    .side-container3 {
      height: 100% !important;
    }
    
    .row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px !important;
    margin-left: 0px !important;
    }
    
    .text{
        font-size:1rem !important;
    }
    .home-form {
    width: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 1rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
@media  only screen and (min-width: 601px) and (max-width: 768px) {
    .nav-link {
    margin-left: 1rem !important;
    }
    .side-container {
        height: 100% !important;
    }
    .side-container3 {
      height: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 0rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
@media  only screen and (max-width: 1024px) {
    .nav-link {
    margin-left: 1rem !important;
    }
    .text{
        font-size:0rem !important;
    }
    .home {
      padding: 94px 0px !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 0rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
    </style>
    <ul class="entity-menu d-flex flex-row align-items-start entity-menu-small nav" role="tablist"
        style="margin-top: 0.2%;margin-left: 1%;margin-right: 1%;font-size: 21px;background-color: #ee293a;">
        <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#Drivrs" style="color: #FFF;">Driver</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#Finance" style="color: #FFF;">Finance</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#Dispatcher" style="color: #FFF;">Dispatcher</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#Monitor" style="color: #FFF;">Monitor</a>
        </li>
    </ul>
    <div style="margin-left: 1%;margin-right: 1%;" class="tab-content">
        <div id="Drivrs" class="row justify-content-center tab-pane active">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <?php if(\Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo \Session::get('error'); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo \Session::get('success'); ?>

                            </div>
                        <?php endif; ?>
                        <table id="Admintable1" class="display nowrap table-res table table-condensed ">

                            <thead>
                                <tr>
                                    <th>
                                        id
                                    </th>
                                    <th>
                                        Name
                                    </th>
                                    <th>
                                        Email
                                    </th>
                                    <th>
                                        Phone
                                    </th>
                                    <th>
                                        Approved
                                    </th>
                                    <th>
                                        Deny
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Driver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Drivers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Drivers->id); ?></td>
                                        <td><?php echo e($Drivers->user->name); ?></td>
                                        <td><?php echo e($Drivers->user->email); ?></td>
                                        <td><?php echo e($Drivers->user->phone); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('UserStatus')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="status" value="approved">
                                                <input type="hidden" name="id" value="<?php echo e($Drivers->id); ?>">
                                                <input type="hidden" name="type" value="driver">
                                                <button id="approved" class="submit btn btn-success">approved</button>                                             
                                            </form>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('UserStatus')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="status" value="deny">
                                                <input type="hidden" name="id" value="<?php echo e($Drivers->id); ?>">
                                                <input type="hidden" name="type" value="driver">
                                                <button id="approved" class="submit btn btn-danger">deny</button>                                             
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div id="Finance" class="row justify-content-center tab-pane fade">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <?php if(\Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo \Session::get('error'); ?>

                            </div>
                        <?php endif; ?>
                        <table id="Admintable2" class="display nowrap table-res table table-condensed ">

                            <thead>
                                <tr>
                                    <th>
                                        id
                                    </th>
                                    <th>
                                        Name
                                    </th>
                                    <th>
                                        Email
                                    </th>
                                    <th>
                                        Phone
                                    </th>
                                    <th>
                                        Approved
                                    </th>
                                    <th>
                                        Deny
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Finance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Finance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Finance->id); ?></td>
                                        <td><?php echo e($Finance->user->name); ?></td>
                                        <td><?php echo e($Finance->user->email); ?></td>
                                        <td><?php echo e($Finance->user->phone); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('UserStatus')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="status" value="approved">
                                                <input type="hidden" name="id" value="<?php echo e($Finance->id); ?>">
                                                <input type="hidden" name="type" value="finance">
                                                <button id="approved" class="submit btn btn-success">approved</button>                                             
                                            </form>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('UserStatus')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="status" value="deny">
                                                <input type="hidden" name="id" value="<?php echo e($Finance->id); ?>">
                                                <input type="hidden" name="type" value="finance">
                                                <button id="approved" class="submit btn btn-danger">deny</button>                                             
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div id="Dispatcher" class="row justify-content-center tab-pane fade">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <?php if(\Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo \Session::get('error'); ?>

                            </div>
                        <?php endif; ?>
                        <table id="Admintable3" class="display nowrap table-res table table-condensed ">

                            <thead>
                                <tr>
                                    <th>
                                        id
                                    </th>
                                    <th>
                                        Name
                                    </th>
                                    <th>
                                        Email
                                    </th>
                                    <th>
                                        Phone
                                    </th>
                                    <th>
                                        Approved
                                    </th>
                                    <th>
                                        Deny
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Dispatcher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Dispatcher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Dispatcher->id); ?></td>
                                        <td><?php echo e($Dispatcher->user->name); ?></td>
                                        <td><?php echo e($Dispatcher->user->email); ?></td>
                                        <td><?php echo e($Dispatcher->user->phone); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('UserStatus')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="status" value="approved">
                                                <input type="hidden" name="id" value="<?php echo e($Dispatcher->id); ?>">
                                                <input type="hidden" name="type" value="dispatcher">
                                                <button id="approved" class="submit btn btn-success">approved</button>                                             
                                            </form>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('UserStatus')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="status" value="deny">
                                                <input type="hidden" name="id" value="<?php echo e($Dispatcher->id); ?>">
                                                <input type="hidden" name="type" value="dispatcher">
                                                <button id="approved" class="submit btn btn-danger">deny</button>                                             
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div id="Monitor" class="row justify-content-center tab-pane fade">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <?php if(\Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo \Session::get('error'); ?>

                            </div>
                        <?php endif; ?>
                        <table id="Admintable4" class="display nowrap table-res table table-condensed ">

                            <thead>
                                <tr>
                                    <th>
                                        id
                                    </th>
                                    <th>
                                        Name
                                    </th>
                                    <th>
                                        Email
                                    </th>
                                    <th>
                                        Phone
                                    </th>
                                    <th>
                                        Approved
                                    </th>
                                    <th>
                                        Deny
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Monitor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Monitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Monitor->id); ?></td>
                                        <td><?php echo e($Monitor->user->name); ?></td>
                                        <td><?php echo e($Monitor->user->email); ?></td>
                                        <td><?php echo e($Monitor->user->phone); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('UserStatus')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="status" value="approved">
                                                <input type="hidden" name="id" value="<?php echo e($Monitor->id); ?>">
                                                <input type="hidden" name="type" value="monitor">
                                                <button id="approved" class="submit btn btn-success">approved</button>                                             
                                            </form>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('UserStatus')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="status" value="deny">
                                                <input type="hidden" name="id" value="<?php echo e($Monitor->id); ?>">
                                                <input type="hidden" name="type" value="monitor">
                                                <button id="approved" class="submit btn btn-danger">deny</button>                                             
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#Admintable1').DataTable();
            $('#Admintable2').DataTable();
            $('#Admintable3').DataTable();
            $('#Admintable4').DataTable();

        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\O Minus\Desktop\NedcoLaravel\resources\views/admin/adminhome.blade.php ENDPATH**/ ?>