

<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>
<style>
.table-res{
        display: block !important;
        overflow-x: auto !important;
    }
    @media  only screen and (min-width: 320px) and (max-width: 568px) {
    .nav-link {
        margin-left: 1rem !important;
    }
    .side-container {
        height: 100% !important;
    }
    .side-container3 {
        height: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
        margin-left: 0rem !important;
    }
    .table-res{
        display: block !important;
        overflow-x: auto !important;
    }
}
@media  only screen and (max-width: 768px) and (max-width: 1024px) {
  .side-container {
         height: 100% !important;
    }
    .side-container3 {
        height: 100% !important;
    }
    .row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px !important;
    margin-left: 0px !important;
    }
    
    .text{
        font-size:1rem !important;
    }
    .home-form {
    width: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 1rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
    }
}
@media  only screen and (max-width: 600px) {
    .nav-link {
    margin-left: 1rem !important;
    }
  .side-container {
    height: 100% !important;
    }
    
    .side-container3 {
      height: 100% !important;
    }
    
    .row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px !important;
    margin-left: 0px !important;
    }
    
    .text{
        font-size:1rem !important;
    }
    .home-form {
    width: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 1rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
@media  only screen and (min-width: 601px) and (max-width: 768px) {
    .nav-link {
    margin-left: 1rem !important;
    }
    .side-container {
        height: 100% !important;
    }
    .side-container3 {
      height: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 0rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
@media  only screen and (max-width: 1024px) {
    .nav-link {
    margin-left: 1rem !important;
    }
    .text{
        font-size:0rem !important;
    }
    .home {
      padding: 94px 0px !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 0rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
</style>
    <div style="margin-left: 1%;margin-right: 1%;" class="tab-content">
        <div id="AllOrders" class="row justify-content-center tab-pane active">
            <div style="margin-top: 10px;" class="col-md-12">
                <div class="card">
                    <?php if(\Session::has('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo \Session::get('error'); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card-header">Assigned Orders</div>
                    <div class="card-body">
                        <div id="alert" style="display: none" class="alert alert-success"></div>
                        <table id="Admintable1" class="display nowrap table-res table table-condensed ">
                            <thead>
                                <tr>
                                    <th>
                                        id
                                    </th>
                                    <th>
                                        Driver Name
                                    </th>
                                    <th>
                                        Client Name
                                    </th>
                                    <th>
                                        Client Number
                                    </th>
                                    <th>
                                        Recipient Name
                                    </th>
                                    <th>
                                        Recipient Number
                                    </th>
                                    <th>
                                        City
                                    </th>
                                    <th>
                                        Recipient Address
                                    </th>
                                    <th>
                                        item Price
                                    </th>
                                    <th>
                                        delivery Price
                                    </th>
                                    <th>
                                        total Price
                                    </th>
                                    <th>
                                        Notes
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $assinedOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($assinedOrder->driver->id); ?></td>
                                        <td><?php echo e($assinedOrder->driver->name); ?></td>
                                        <td><?php echo e($assinedOrder->order->SenderName); ?></td>
                                        <td><?php echo e($assinedOrder->order->SenderNumber); ?></td>
                                        <td><?php echo e($assinedOrder->order->RecipientName); ?></td>
                                        <td><?php echo e($assinedOrder->order->RecipientNumber); ?></td>
                                        <td><?php echo e($assinedOrder->order->city); ?></td>
                                        <td><?php echo e($assinedOrder->order->RecipientAddress); ?></td>
                                        <td><?php echo e($assinedOrder->order->itemPrice); ?></td>
                                        <td><?php echo e($assinedOrder->order->deliveryPrice); ?></td>
                                        <td><?php echo e($assinedOrder->order->totalPrice); ?></td>
                                        <td><?php echo e($assinedOrder->order->notes); ?></td>
                                        <td>
                                            <input type="hidden" name="id" class="order_id" value="<?php echo e($assinedOrder->order->id); ?>"> 
                                            <select name="status" class="form-control status" data-id="<?php echo e($assinedOrder->order->id); ?>">
                                                <option value="Delivered" <?php if($assinedOrder->order->status == 'Delivered'): ?> selected <?php endif; ?>>Delivered</option>
                                                <option value="Pending" <?php if($assinedOrder->order->status == 'Pending'): ?> selected <?php endif; ?>>Pending</option>
                                                <option value="Out For Delivery" <?php if($assinedOrder->order->status == 'Out For Delivery'): ?> selected <?php endif; ?>>Out For Delivery</option>
                                                <option value="No Answer" <?php if($assinedOrder->order->status == 'No Answer'): ?> selected <?php endif; ?>>No Answer</option>
                                                <option value="Turned  Answer" <?php if($assinedOrder->order->status == 'Turned Off'): ?> selected <?php endif; ?>>Turned Off</option>
                                                <option value="Disconnected" <?php if($assinedOrder->order->status == 'Disconnected'): ?> selected <?php endif; ?>>Disconnected</option>
                                                <option value="Out Of Reach" <?php if($assinedOrder->order->status == 'Out Of Reach'): ?> selected <?php endif; ?>>Out Of Reach</option>
                                                <option value="Cancelled" <?php if($assinedOrder->order->status == 'Cancelled'): ?> selected <?php endif; ?>>Cancelled</option>
                                                <option value="Rejected" <?php if($assinedOrder->order->status == 'Rejected'): ?> selected <?php endif; ?>>Rejected</option>
                                                <option value="Rejected With Charges" <?php if($assinedOrder->order->status == 'Rejected With Charges'): ?> selected <?php endif; ?>>Rejected With Charges</option>
                                                <option value="Returned" <?php if($assinedOrder->order->status == 'Returned'): ?> selected <?php endif; ?>>Returned</option>
                                            </select>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#Admintable1').DataTable();

            $('.status').on('change', function(event){
                event.preventDefault();
                let _token = '<?php echo e(csrf_token()); ?>';
                let id = $(this).attr('data-id');
                console.log(id);
                $.ajax({
                    url: "<?php echo e(route('cheangeStatus')); ?>",
                    type:"POST",
                    data:{
                        status: this.value, 
                        id: id,
                        _token: _token
                    },
                    success:function(response){
                        console.log(response);
                        $('#alert').css('display', 'block');
                        $('#alert').text(response)
                    },
                    error:function(){
                        console.log('error');
                    },
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/mqjaujmy/NEDCO/resources/views/monitor/assignedOrders.blade.php ENDPATH**/ ?>