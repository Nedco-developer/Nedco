

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <style>
        .entity-menu>.nav-item>a.active {
            background-color: #000;
            border-bottom: 0px solid black !important;
        }
    </style>
    <ul class="entity-menu d-flex flex-row align-items-start entity-menu-small nav" role="tablist"
        style="margin-top: 0.2%;margin-left: 1%;margin-right: 1%;font-size: 21px;background-color: #ee293a;">
        <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#Drivrs" style="color: #FFF;">Driver</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#Finance" style="color: #FFF;">Finance</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#Dispatcher" style="color: #FFF;">Dispatcher</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#Monitor" style="color: #FFF;">Monitor</a>
        </li>
    </ul>
    <div style="margin-left: 1%;margin-right: 1%;" class="tab-content">
        <div id="Drivrs" class="row justify-content-center tab-pane active">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <?php if(\Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo \Session::get('error'); ?>

                            </div>
                        <?php endif; ?>
                        <table id="Admintable1">

                            <thead>
                                <tr>
                                    <th>
                                        Name
                                    </th>
                                    <th>
                                        Email
                                    </th>
                                    <th>
                                        Phone
                                    </th>
                                    <th>
                                        Age
                                    </th>
                                    <th>
                                        Approved
                                    </th>
                                    <th>
                                        Deny
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Driver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Drivers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Drivers->user->name); ?></td>
                                        <td><?php echo e($Drivers->user->email); ?></td>
                                        <td><?php echo e($Drivers->user->phone); ?></td>
                                        <td><?php echo e($Drivers->age); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('UserStatus')); ?>" method="get">
                                                <input type="hidden" name="status" value="approved">
                                                <input type="hidden" name="id" value="<?php echo e($Drivers->id); ?>">
                                                <input type="hidden" name="type" value="driver">
                                                <button id="approved" class="submit btn btn-success">approved</button>                                             
                                            </form>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('UserStatus')); ?>" method="get">
                                                <input type="hidden" name="status" value="deny">
                                                <input type="hidden" name="id" value="<?php echo e($Drivers->id); ?>">
                                                <input type="hidden" name="type" value="driver">
                                                <button id="approved" class="submit btn btn-danger">deny</button>                                             
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div id="Finance" class="row justify-content-center tab-pane fade">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <?php if(\Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo \Session::get('error'); ?>

                            </div>
                        <?php endif; ?>
                        <table id="Admintable2">

                            <thead>
                                <tr>
                                    <th>
                                        Name
                                    </th>
                                    <th>
                                        Email
                                    </th>
                                    <th>
                                        Phone
                                    </th>
                                    <th>
                                        Age
                                    </th>
                                    <th>
                                        Approved
                                    </th>
                                    <th>
                                        Deny
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Finance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Finance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Finance->user->name); ?></td>
                                        <td><?php echo e($Finance->user->email); ?></td>
                                        <td><?php echo e($Finance->user->phone); ?></td>
                                        <td><?php echo e($Finance->age); ?></td>
                                        <td><a id="approved"
                                                href="/UserStatus?id=<?php echo e($Finance->id); ?>&status=approved&type=driver"
                                                class="btn btn-success">approved</a> </td>
                                        <td>
                                            <a id="approved"
                                                href="/UserStatus?id=<?php echo e($Finance->id); ?>&status=deny&type=driver"
                                                class="btn btn-danger">deny</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div id="Dispatcher" class="row justify-content-center tab-pane fade">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <?php if(\Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo \Session::get('error'); ?>

                            </div>
                        <?php endif; ?>
                        <table id="Admintable3">

                            <thead>
                                <tr>
                                    <th>
                                        Name
                                    </th>
                                    <th>
                                        Email
                                    </th>
                                    <th>
                                        Phone
                                    </th>
                                    <th>
                                        Age
                                    </th>
                                    <th>
                                        Approved
                                    </th>
                                    <th>
                                        Deny
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Dispatcher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Dispatcher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Dispatcher->user->name); ?></td>
                                        <td><?php echo e($Dispatcher->user->email); ?></td>
                                        <td><?php echo e($Dispatcher->user->phone); ?></td>
                                        <td><?php echo e($Dispatcher->age); ?></td>
                                        <td><a id="approved"
                                                href="/UserStatus?id=<?php echo e($Dispatcher->id); ?>&status=approved&type=driver"
                                                class="btn btn-success">approved</a> </td>
                                        <td>
                                            <a id="approved"
                                                href="/UserStatus?id=<?php echo e($Dispatcher->id); ?>&status=deny&type=driver"
                                                class="btn btn-danger">deny</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div id="Monitor" class="row justify-content-center tab-pane fade">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <?php if(\Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo \Session::get('error'); ?>

                            </div>
                        <?php endif; ?>
                        <table id="Admintable4">

                            <thead>
                                <tr>
                                    <th>
                                        Name
                                    </th>
                                    <th>
                                        Email
                                    </th>
                                    <th>
                                        Phone
                                    </th>
                                    <th>
                                        Age
                                    </th>
                                    <th>
                                        Approved
                                    </th>
                                    <th>
                                        Deny
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Monitor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $Monitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Monitor->user->name); ?></td>
                                        <td><?php echo e($Monitor->user->email); ?></td>
                                        <td><?php echo e($Monitor->user->phone); ?></td>
                                        <td><?php echo e($Monitor->age); ?></td>
                                        <td><a id="approved"
                                                href="/UserStatus?id=<?php echo e($Monitor->id); ?>&status=approved&type=driver"
                                                class="btn btn-success">approved</a> </td>
                                        <td>
                                            <a id="approved"
                                                href="/UserStatus?id=<?php echo e($Monitor->id); ?>&status=deny&type=driver"
                                                class="btn btn-danger">deny</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#Admintable1').DataTable();
            $('#Admintable2').DataTable();
            $('#Admintable3').DataTable();
            $('#Admintable4').DataTable();

        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/mqjaujmy/NEDCO/resources/views/admin/adminhome.blade.php ENDPATH**/ ?>