

<?php $__env->startSection('title', 'Edit Driver'); ?>

<?php $__env->startSection('content'); ?>
<style>
    @media  only screen and (min-width: 320px) and (max-width: 568px) {
    .nav-link {
        margin-left: 1rem !important;
    }
    .side-container {
        height: 100% !important;
    }
    .side-container3 {
        height: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
        margin-left: 0rem !important;
    }
    .table-res{
        display: block !important;
        overflow-x: auto !important;
    }
}
@media  only screen and (max-width: 768px) and (max-width: 1024px) {
  .side-container {
         height: 100% !important;
    }
    .side-container3 {
        height: 100% !important;
    }
    .row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px !important;
    margin-left: 0px !important;
    }
    
    .text{
        font-size:1rem !important;
    }
    .home-form {
    width: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 1rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
    }
}
@media  only screen and (max-width: 600px) {
    .nav-link {
    margin-left: 1rem !important;
    }
  .side-container {
    height: 100% !important;
    }
    
    .side-container3 {
      height: 100% !important;
    }
    
    .row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px !important;
    margin-left: 0px !important;
    }
    
    .text{
        font-size:1rem !important;
    }
    .home-form {
    width: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 1rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
@media  only screen and (min-width: 601px) and (max-width: 768px) {
    .nav-link {
    margin-left: 1rem !important;
    }
    .side-container {
        height: 100% !important;
    }
    .side-container3 {
      height: 100% !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 0rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
@media  only screen and (max-width: 1024px) {
    .nav-link {
    margin-left: 1rem !important;
    }
    .text{
        font-size:0rem !important;
    }
    .home {
      padding: 94px 0px !important;
    }
    .nav-item {
    height: 5rem !important;
     margin-left: 0rem !important;
    }
    .table-res{
            display: block !important;
        overflow-x: auto !important;
        }
}
</style>
<br>
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                    <div class="card-header"><?php echo e($Admin->user->type); ?>s Orders</div>
                    <div class="card-body">
                    <table id="Admintable1" class="display nowrap table-res table table-condensed ">
                        <thead>
                            <tr>
                                <th>
                                    id
                                </th>
                                <th>
                                    payment status
                                </th>
                                <th>
                                    city
                                </th>
                                <th>
                                    item Price
                                </th>
                                <th>
                                    delivery Price
                                </th>
                                <th>
                                    total Price
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $Orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($order->id); ?></td>
                                    <td><?php echo e($order->payment_status); ?></td>
                                    <td><?php echo e($order->city); ?></td>
                                    <td><?php echo e($order->itemPrice); ?></td>
                                    <td><?php echo e($order->deliveryPrice); ?></td>
                                    <td><?php echo e($order->totalPrice); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                                <tr>
                                    <td>Item Price :</td>
                                    <td><?php echo e($item); ?></td>
                                    <?php if($Admin->user->type == "driver"): ?>
                                    <td>Driver Price :</td>
                                    <?php else: ?>
                                    <td>Delivery Price :</td>
                                    <?php endif; ?>
                                    <td><?php echo e($delivery); ?></td>
                                    <td>Total Price:</td>
                                    <td><?php echo e($total); ?></td>
                                </tr>
                        </tfoot>
                    </table>
                    </div>
                </div>
                <br>
            <div class="card">
                <div class="card-header"><?php echo e(__('Financial Accounts')); ?></div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('SaveAccounts')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo \Session::get('success'); ?>

                            </div>
                        <?php endif; ?>

                        <input type="hidden" name="user_id" value="<?php echo e($Admin->user->id); ?>" />

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">name</label>
                            <div class="col-md-5">
                                <input id="name" type="text" disabled class="form-control" name="name" value="<?php echo e($Admin->user->name); ?>" >
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="TotalPrice" class="col-md-4 col-form-label text-md-right">Total Price</label>
                            <div class="col-md-5">
                                <input id="TotalPrice" type="text" disabled class="form-control" name="TotalPrice" value="<?php echo e($TotalPrice); ?>" >
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="Price" class="col-md-4 col-form-label text-md-right">Price</label>
                            <div class="col-md-5">
                                <input id="Price" type="number" step="0.01" class="form-control" name="Price" value=""  required autofocus>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="calPrice" class="col-md-4 col-form-label text-md-right">result</label>
                            <div class="col-md-5">
                                <input id="calPrice" type="text" disabled class="form-control" value="">
                                <input id="result" type="hidden" class="form-control" name="result" value="">
                            </div>
                        </div>
                        
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('save')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $('#Admintable1').DataTable();
    });
    $('#Price').keyup(function () {
        let total = $('#TotalPrice').val();
        var sum = Number(total) - Number($(this).val());
        $('#calPrice').attr('value', sum.toFixed(2));
        $('#result').attr('value', sum.toFixed(2));
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/mqjaujmy/NEDCO/resources/views/FinancialAccounts/Accounts.blade.php ENDPATH**/ ?>