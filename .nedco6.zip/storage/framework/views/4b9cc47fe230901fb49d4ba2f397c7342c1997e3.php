<!doctype html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href='https://fonts.googleapis.com/css?family=Cairo' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/nedco/css/dashboard_style.css">
    <link rel="stylesheet" href="/nedco/css/style.css">
    <link rel="stylesheet" href="/nedco/css/pages-style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
        integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"
        integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"
        integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.19.2/axios.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/css/intlTelInput.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/js/intlTelInput-jquery.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.0/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.0/js/buttons.flash.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.0/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.0/js/buttons.print.min.js"></script>

    <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.4/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.4/js/buttons.flash.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.4/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.4/js/buttons.print.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote.min.js"></script>

    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />

    <script src="/nedco/js/sidebar.js"></script>
    <script src="/nedco/js/pages.js"></script>
    <script src="/nedco/js/auth.js"></script>
    <link rel="stylesheet" href="/nedco/css/pages-style.css">
    <?php echo $__env->yieldContent('header'); ?>
    <title>Nedco - <?php echo $__env->yieldContent('title'); ?></title>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-style">
            
            <div id="navbarSupportedContent">
                
                <div class="navbar-nav mr-auto">
                    <a href="#menu-toggle" class="float-right" id="menu-toggle"><img src="images/open-menu.png"
                            class="menu-toggle" /></a>

                        <a style="margin-left:1rem ;font-size: 40px; " class="navbar-brand" href="<?php echo e(url('home')); ?>">
                            <?php echo e(config('app.name', 'NEDCO')); ?>

                        </a>
                        <h6 style="color: white;margin-top: 2.7rem;">National Express Delivery Company L.L.C.</h6>
                </div>
               
                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                <?php if(Auth::user()): ?>
                   <?php echo e(Auth::user()->name); ?>

                <?php endif; ?>
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
            </div>
        </nav>
    </header>
    <div id="wrapper">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <?php if(Auth::user()): ?>
                <?php if(Auth::user()->type == 'super_admin'): ?>
                    <li>
                        <div class="wrapper wrapper1 <?php if(\Request::is('location') || \Request::is('addlocation')): ?> active <?php endif; ?>" id="wrapper_11">
                            <p class="click-text">
                                Location <span class="arrow"></span>
                            </p>
                            <ul>
                            <li><a href="/nedco/location">Location</a></li>
                            <li><a href="/nedco/addlocation">Add Location</a></li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <div class="wrapper wrapper1 <?php if(\Request::is('admin') || \Request::is('register-admin')): ?> active <?php endif; ?>" id="wrapper_1">
                            <p class="click-text">
                                Admin <span class="arrow"></span>
                            </p>
                            <ul>
                                <li><a href="/nedco/admin">View Admin</a></li>
                                <li><a href="/nedco/register-admin">Add Admin</a></li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <div class="wrapper wrapper1 <?php if(\Request::is('client')): ?> active <?php endif; ?>" id="wrapper_2">
                            <p class="click-text">
                                Client <span class="arrow"></span>
                            </p>
                            <ul>
                                <li><a href="/nedco/client">View Client</a></li>
                                <li><a href="/nedco/registerAdmin?name=client">Add Client</a></li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <div class="wrapper wrapper1 <?php if(\Request::is('driver')): ?> active <?php endif; ?>" id="wrapper_3">
                            <p class="click-text">
                                Driver <span class="arrow"></span>
                            </p>
                            <ul>
                                <li><a href="/nedco/driver">View Driver</a></li>
                                <li><a href="/nedco/registerAdmin?name=driver">Add Driver</a></li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <div class="wrapper wrapper1 <?php if(\Request::is('finance')): ?> active <?php endif; ?>" id="wrapper_4">
                            <p class="click-text">
                                Finance <span class="arrow"></span>
                            </p>
                            <ul>
                                <li><a href="/nedco/finance">View Finance</a></li>
                                <li><a href="/nedco/registerAdmin?name=finance">Add Finance</a></li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <div class="wrapper wrapper1 <?php if(\Request::is('dispatcher')): ?> active <?php endif; ?>" id="wrapper_5">
                            <p class="click-text">
                                Dispatcher <span class="arrow"></span>
                            </p>
                            <ul>
                                <li><a href="/nedco/dispatcher">View Dispatcher</a></li>
                                <li><a href="/nedco/registerAdmin?name=dispatcher">Add Dispatcher</a></li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <div class="wrapper wrapper1 <?php if(\Request::is('monitor')): ?> active <?php endif; ?>" id="wrapper_6">
                            <p class="click-text">
                                Monitor <span class="arrow"></span>
                            </p>
                            <ul>
                                <li><a href="/nedco/monitor">View Monitor</a></li>
                                <li><a href="/nedco/registerAdmin?name=monitor">Add Monitor</a></li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <div class="wrapper wrapper1" id="wrapper_7">
                            <p class="click-text">
                                Request <span class="arrow"></span>
                            </p>
                            <ul>
                                <li><a href="/nedco/home">View All Request</a></li>
                            </ul>
                        </div>
                    </li>
                <li>
                        <div class="wrapper wrapper1 <?php if(\Request::is('viewAllOrders') || \Request::is('addOrder')): ?> active <?php endif; ?>" id="wrapper_8">
                            <p class="click-text">
                                Orders <span class="arrow"></span>
                            </p>
                            <ul>
                                <li><a href="/nedco/viewAllOrders">All Orders</a></li>
                                <li><a href="/nedco/addOrder">Add New Order</a></li>
                            </ul>
                        </div>
                    </li>

                <?php elseif((Auth::user()->type == 'admin')): ?>
                <li>
                    <div class="wrapper wrapper1" id="wrapper_11">
                        <p class="click-text">
                            Location <span class="arrow"></span>
                        </p>
                        <ul>
                        <li><a href="/nedco/location">Location</a></li>
                        <li><a href="/nedco/addlocation">Add Location</a></li>
                        </ul>
                    </div>
                </li>
                <li>
                    <div class="wrapper wrapper1" id="wrapper_2">
                        <p class="click-text">
                            Client <span class="arrow"></span>
                        </p>
                        <ul>
                            <li><a href="/nedco/client">View Client</a></li>
                            <li><a href="/nedco/registerAdmin?name=client">Add Client</a></li>
                        </ul>
                    </div>
                </li>
                <li>
                    <div class="wrapper wrapper1" id="wrapper_3">
                        <p class="click-text">
                            Driver <span class="arrow"></span>
                        </p>
                        <ul>
                            <li><a href="/nedco/driver">View Driver</a></li>
                            <li><a href="/nedco/registerAdmin?name=driver">Add Driver</a></li>
                        </ul>
                    </div>
                </li>
                <li>
                    <div class="wrapper wrapper1" id="wrapper_4">
                        <p class="click-text">
                            Finance <span class="arrow"></span>
                        </p>
                        <ul>
                            <li><a href="/nedco/finance">View Finance</a></li>
                            <li><a href="/nedco/registerAdmin?name=finance">Add Finance</a></li>
                        </ul>
                    </div>
                </li>
                <li>
                    <div class="wrapper wrapper1" id="wrapper_5">
                        <p class="click-text">
                            Dispatcher <span class="arrow"></span>
                        </p>
                        <ul>
                            <li><a href="/nedco/dispatcher">View Dispatcher</a></li>
                            <li><a href="/nedco/registerAdmin?name=dispatcher">Add Dispatcher</a></li>
                        </ul>
                    </div>
                </li>
                <li>
                    <div class="wrapper wrapper1" id="wrapper_6">
                        <p class="click-text">
                            Monitor <span class="arrow"></span>
                        </p>
                        <ul>
                            <li><a href="/nedco/monitor">View Monitor</a></li>
                            <li><a href="/nedco/registerAdmin?name=monitor">Add Monitor</a></li>
                        </ul>
                    </div>
                </li>
                <li>
                    <div class="wrapper wrapper1" id="wrapper_7">
                        <p class="click-text">
                            Request <span class="arrow"></span>
                        </p>
                        <ul>
                            <li><a href="/nedco/home">View All Request</a></li>
                        </ul>
                    </div>
                </li>
            <li>
                    <div class="wrapper wrapper1" id="wrapper_8">
                        <p class="click-text">
                            Orders <span class="arrow"></span>
                        </p>
                        <ul>
                            <li><a href="/nedco/viewAllOrders">All Orders</a></li>
                            <li><a href="/nedco/addOrder">Add New Order</a></li>
                        </ul>
                    </div>
                </li>


                <?php elseif((Auth::user()->type == 'client')): ?>
                    <li>
                        <div class="wrapper wrapper1" id="wrapper_8">
                            <p class="click-text">
                                Order <span class="arrow"></span>
                            </p>
                            <ul>
                            <li><a href="/nedco/Order?id=<?php echo e(Auth::user()->id); ?>">New Order</a></li>
                                <li><a href="/nedco/viewOrder?id=<?php echo e(Auth::user()->id); ?>">View My Orders</a></li>
                            </ul>
                        </div>
                    </li>
                
                <?php elseif((Auth::user()->type == 'dispatcher')): ?>
                    <li>
                        <div class="wrapper wrapper1" id="wrapper_8">
                            <p class="click-text">
                                Order <span class="arrow"></span>
                            </p>
                            <ul>
                            <li><a href="/nedco/DispatcherOrder">Orders</a></li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <div class="wrapper wrapper1" id="wrapper_9">
                            <p class="click-text">
                                Drivers <span class="arrow"></span>
                            </p>
                            <ul>
                            <li><a href="/nedco/ViewAllDrivers">View All Drivers</a></li>
                            </ul>
                        </div>
                    </li>
               
                <?php elseif((Auth::user()->type == 'driver')): ?>
                    <li>
                        <a href="/nedco/driverOrder">My Orders</a>
                    </li>

                <?php elseif((Auth::user()->type == 'monitor')): ?>
                <li>
                    <a href="/nedco/monitor-clients">View Clients</a>
                </li>
                <li>
                    <a href="/nedco/monitor-drivers">View Drivers</a>
                </li>
                <li>
                    <a href="/nedco/monitor-orders">View Orders</a>
                </li>
                <li>
                    <a href="/nedco/monitor-assigned-orders">Assigned Orders</a>
                </li>
                <?php endif; ?>
             <?php endif; ?>

               
        </div>
        <!-- /#sidebar-wrapper -->




        <!-- Page Content -->
        <div class="body-footer-scroll">
            <div id="page-content-wrapper">
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
    </div>


    <br />
</body>

</html>
<?php /**PATH /home4/mqjaujmy/NEDCO/resources/views/layouts/dashboardApp.blade.php ENDPATH**/ ?>